# Arquitectura del Proyecto NBA Machine Learning

## Visión General

Este proyecto implementa un sistema completo de Machine Learning para análisis de partidos de la NBA, integrando tanto técnicas de aprendizaje supervisado como no supervisado.

## Estructura del Proyecto

```
proyecto-ml-final/
├── conf/
│   ├── base/
│   │   ├── catalog.yml                    # Catálogo de datasets
│   │   ├── parameters.yml                # Parámetros generales
│   │   ├── parameters_data_processing.yml
│   │   ├── parameters_data_science.yml
│   │   ├── parameters_regression.yml
│   │   ├── parameters_unsupervised.yml   # ← NUEVO
│   │   └── parameters_reporting.yml
│   └── local/
├── data/
│   ├── 01_raw/                          # Datos originales
│   ├── 02_intermediate/                 # Datos procesados
│   ├── 03_primary/                      # Datos listos para modelado
│   ├── 04_feature/                      # Features engineering
│   ├── 05_model_input/                  # Datos de entrada para modelos
│   ├── 06_models/                       # Modelos entrenados
│   ├── 07_model_output/                 # Predicciones y métricas
│   └── 08_reporting/                    # Reportes y visualizaciones
├── dags/
│   └── nba_ml_pipeline.py              # DAG de Airflow (ACTUALIZADO)
├── src/nba/pipelines/
│   ├── data_processing/                 # Limpieza y preparación
│   ├── data_science/                    # Clasificación
│   ├── regression/                     # Regresión
│   ├── unsupervised_learning/          # ← NUEVO
│   │   ├── clustering/
│   │   ├── dimensionality_reduction/
│   │   ├── anomaly_detection/
│   │   └── association_rules/
│   ├── reporting/                       # Reportes
│   └── regression_reporting/
├── notebooks/
│   ├── 01-04: Notebooks de EP1 y EP2
│   ├── 05_unsupervised_learning.ipynb  # ← NUEVO
│   └── 06_final_analysis.ipynb         # ← NUEVO
├── docs/
│   ├── architecture.md                  # ← NUEVO
│   └── unsupervised_analysis.md         # ← NUEVO
├── docker/
│   ├── Dockerfile                       # ACTUALIZADO
│   └── docker-compose.yml              # ACTUALIZADO
└── README.md
```

## Componentes Principales

### 1. Framework Kedro

**Pipelines Implementados:**
- `data_processing`: Limpieza y feature engineering
- `data_science`: Modelos de clasificación
- `regression`: Modelos de regresión
- `unsupervised_learning`: Aprendizaje no supervisado (NUEVO)
  - `clustering`: 5 algoritmos
  - `dimensionality_reduction`: 4 técnicas
  - `anomaly_detection`: 4 algoritmos
  - `association_rules`: 2 algoritmos
- `reporting`: Visualizaciones y reportes

**Registro de Pipelines:**
```python
pipelines = {
    "data_processing": ...,
    "data_science": ...,
    "unsupervised_learning": ...,  # ← NUEVO
    "full_unsupervised_pipeline": ...,  # ← NUEVO
    "complete_ml_pipeline": ...,  # ← NUEVO
}
```

### 2. Orquestación Airflow

**DAG Principal:** `nba_ml_pipeline`

**Flujo de Ejecución:**
```
check_data_availability
    ↓
data_processing_pipeline
    ↓
data_science_pipeline
    ↓
unsupervised_learning_pipeline  # ← NUEVO
    ↓
reporting_pipeline
    ↓
consolidate_results
    ↓
notify_completion
```

**Tareas de Unsupervised Learning:**
- Ejecuta pipeline completo de aprendizaje no supervisado
- Genera métricas y visualizaciones
- Integra resultados con pipeline supervisado

### 3. Versionado DVC

**Stages Configurados:**
- `data_processing`
- `data_science`
- `unsupervised_learning`  # ← NUEVO
- `reporting`
- `ml_pipeline`

**Artifacts Versionados:**
- Modelos de clustering (K-Means, DBSCAN, Hierarchical, GMM, OPTICS)
- Modelos de reducción dimensional (PCA, t-SNE, UMAP, SVD)
- Modelos de detección de anomalías
- Métricas y comparaciones

### 4. Docker

**Contenedores:**
- `nba-ml`: Pipeline principal
- `nba-jupyter`: Jupyter notebooks
- `nba-airflow`: Orquestación Airflow

**Librerías Instaladas:**
- scikit-learn>=1.3.0
- plotly>=5.0.0
- umap-learn>=0.5.0
- pyod>=1.1.0
- mlxtend>=0.22.0
- hdbscan>=0.8.0
- shap>=0.42.0

## Flujo de Datos

### Pipeline Completo

```
01_raw (CSV)
    ↓
data_processing
    ↓
02_intermediate (games_cleaned, games_features)
    ↓
03_primary (model_input_table)
    ↓
├── data_science → 06_models (clasificadores)
├── regression → 06_models (regresores)
└── unsupervised_learning → 06_models (clustering, DR, anomalías)  # ← NUEVO
    ↓
07_model_output (métricas, predicciones)
    ↓
08_reporting (visualizaciones, reportes)
```

## Técnicas Implementadas

### Aprendizaje Supervisado
- **Clasificación**: Random Forest, Gradient Boosting, Logistic Regression, SVM, KNN, etc.
- **Regresión**: Random Forest Regressor, Gradient Boosting Regressor, Linear Regression, etc.

### Aprendizaje No Supervisado (NUEVO)

#### Clustering
1. **K-Means**: Clustering particional basado en centroides
2. **DBSCAN**: Clustering basado en densidad
3. **Hierarchical Clustering**: Clustering jerárquico
4. **Gaussian Mixture Models**: Clustering probabilístico
5. **OPTICS**: Alternativa a DBSCAN para densidad variable

**Métricas Implementadas:**
- Silhouette Score
- Davies-Bouldin Index
- Calinski-Harabasz Index
- Elbow Method
- Dendrogramas

#### Reducción de Dimensionalidad
1. **PCA**: Análisis de componentes principales
   - Varianza explicada
   - Loadings
   - Biplots
2. **t-SNE**: Visualización 2D/3D de alta dimensión
3. **UMAP**: Alternativa moderna a t-SNE
4. **Truncated SVD**: Para datos sparse

#### Detección de Anomalías
1. **Isolation Forest**
2. **Local Outlier Factor (LOF)**
3. **One-Class SVM**
4. **Autoencoders**

#### Reglas de Asociación
1. **Apriori Algorithm**
2. **FP-Growth**
3. **Métricas**: Support, Confidence, Lift

## Configuración

### Parámetros

**`parameters_unsupervised.yml`**: Configuración de todos los algoritmos de aprendizaje no supervisado:
- Clustering: K-Means, DBSCAN, Hierarchical, GMM, OPTICS
- Reducción dimensional: PCA, t-SNE, UMAP, SVD
- Detección de anomalías: Isolation Forest, LOF, One-Class SVM, Autoencoder
- Reglas de asociación: Apriori, FP-Growth

### Catálogo

**`catalog.yml`**: Define todos los datasets de entrada y salida:
- Datos preparados para cada técnica
- Modelos entrenados
- Métricas y comparaciones
- Visualizaciones

## Ejecución

### Local
```bash
# Pipeline completo
kedro run

# Solo unsupervised learning
kedro run --pipeline unsupervised_learning

# Solo clustering
kedro run --pipeline unsupervised_learning.clustering
```

### Docker
```bash
docker-compose up
```

### Airflow
- Acceder a: http://localhost:8080
- Activar DAG: `nba_ml_pipeline`
- Monitorear ejecución en tiempo real

### DVC
```bash
# Ejecutar stage de unsupervised learning
dvc repro unsupervised_learning

# Ver métricas
dvc metrics show
```

## Extensibilidad

La arquitectura está diseñada para ser fácilmente extensible:

1. **Nuevos algoritmos**: Agregar en `nodes.py` correspondiente
2. **Nuevas métricas**: Extender funciones de evaluación
3. **Nuevos pipelines**: Crear en `src/nba/pipelines/`
4. **Nuevas visualizaciones**: Agregar funciones en `nodes.py`

## Mantenimiento

- **Logs**: `logs/` y `airflow/logs/`
- **Métricas**: `metrics/`
- **Visualizaciones**: `data/08_reporting/`
- **Modelos**: `data/06_models/` (versionados con DVC)

