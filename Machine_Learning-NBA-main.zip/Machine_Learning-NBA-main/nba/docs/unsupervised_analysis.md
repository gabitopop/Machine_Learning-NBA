# Análisis de Aprendizaje No Supervisado - NBA

## Resumen Ejecutivo

Este documento describe la implementación completa de técnicas de aprendizaje no supervisado para el análisis de datos de partidos de la NBA.

## 1. Clustering

### Objetivo
Identificar patrones y grupos naturales en los datos de partidos NBA sin usar etiquetas.

### Algoritmos Implementados

#### 1.1 K-Means
- **Tipo**: Clustering particional basado en centroides
- **Parámetros**: `n_clusters` (determinado por método del codo)
- **Ventajas**: Rápido, escalable, fácil de interpretar
- **Desventajas**: Requiere especificar número de clusters, sensible a inicialización

#### 1.2 DBSCAN
- **Tipo**: Clustering basado en densidad
- **Parámetros**: `eps` (distancia), `min_samples` (puntos mínimos)
- **Ventajas**: Encuentra clusters de forma arbitraria, detecta outliers
- **Desventajas**: Sensible a parámetros, dificultad con densidades variables

#### 1.3 Hierarchical Clustering
- **Tipo**: Clustering jerárquico aglomerativo
- **Parámetros**: `n_clusters`, `linkage` (ward, complete, average)
- **Ventajas**: No requiere número de clusters a priori, genera dendrograma
- **Desventajas**: Computacionalmente costoso para grandes datasets

#### 1.4 Gaussian Mixture Models (GMM)
- **Tipo**: Clustering probabilístico
- **Parámetros**: `n_components` (número de mezclas)
- **Ventajas**: Modelo probabilístico, clusters suaves
- **Desventajas**: Asume distribución gaussiana

#### 1.5 OPTICS
- **Tipo**: Clustering basado en densidad (alternativa a DBSCAN)
- **Parámetros**: `min_samples`, `max_eps`
- **Ventajas**: Mejor que DBSCAN para densidades variables
- **Desventajas**: Más lento que DBSCAN

### Métricas de Evaluación

#### Silhouette Score
- **Rango**: [-1, 1]
- **Interpretación**: 
  - Cerca de 1: Clusters bien separados
  - Cerca de 0: Clusters solapados
  - Cerca de -1: Muestras asignadas incorrectamente

#### Davies-Bouldin Index
- **Rango**: [0, ∞)
- **Interpretación**: Menor es mejor
- **Mide**: Relación entre dispersión intra-cluster y separación inter-cluster

#### Calinski-Harabasz Index
- **Rango**: [0, ∞)
- **Interpretación**: Mayor es mejor
- **Mide**: Relación entre varianza entre clusters y varianza dentro de clusters

#### Elbow Method
- **Propósito**: Determinar número óptimo de clusters para K-Means
- **Método**: Graficar inercia vs número de clusters, buscar "codo"

#### Dendrogramas
- **Propósito**: Visualizar jerarquía de clusters
- **Uso**: Determinar número de clusters y estructura jerárquica

### Resultados Esperados

Los modelos de clustering permiten:
- Identificar tipos de partidos (alta puntuación, defensivos, etc.)
- Segmentar equipos por estilo de juego
- Detectar patrones temporales en la temporada

## 2. Reducción de Dimensionalidad

### Objetivo
Reducir el número de características manteniendo la información más importante.

### Técnicas Implementadas

#### 2.1 PCA (Análisis de Componentes Principales)
- **Tipo**: Transformación lineal
- **Parámetros**: `n_components` (número de componentes)
- **Métricas**:
  - Varianza explicada por componente
  - Varianza acumulada
  - Loadings (contribución de cada feature)
- **Visualizaciones**:
  - Gráfico de varianza explicada
  - Biplot (componentes principales)
  - Heatmap de loadings

#### 2.2 t-SNE (t-Distributed Stochastic Neighbor Embedding)
- **Tipo**: Reducción no lineal para visualización
- **Parámetros**: `n_components` (2 o 3), `perplexity`, `n_iter`
- **Uso**: Visualización 2D/3D de alta dimensionalidad
- **Limitaciones**: Solo para visualización, no para reducción previa a ML

#### 2.3 UMAP (Uniform Manifold Approximation and Projection)
- **Tipo**: Reducción no lineal moderna
- **Parámetros**: `n_components`, `n_neighbors`, `min_dist`
- **Ventajas**: Más rápido que t-SNE, preserva estructura global y local
- **Uso**: Visualización y reducción dimensional

#### 2.4 Truncated SVD
- **Tipo**: Descomposición de valores singulares truncada
- **Parámetros**: `n_components`
- **Uso**: Datos sparse, alternativa a PCA
- **Ventajas**: Eficiente para matrices grandes y sparse

### Interpretación

**PCA:**
- Componentes principales capturan direcciones de máxima varianza
- Loadings indican qué características contribuyen más
- Varianza acumulada muestra cuánta información se preserva

**t-SNE/UMAP:**
- Visualizaciones 2D muestran estructura de datos
- Clusters visibles indican grupos naturales
- Distancias preservadas indican similitudes

## 3. Detección de Anomalías

### Objetivo
Identificar partidos o patrones inusuales en los datos.

### Algoritmos Implementados

#### 3.1 Isolation Forest
- **Principio**: Aísla anomalías en lugar de perfilar normalidad
- **Parámetros**: `contamination` (proporción esperada de anomalías)
- **Ventajas**: Eficiente, maneja múltiples tipos de anomalías
- **Uso**: Detectar partidos con estadísticas inusuales

#### 3.2 Local Outlier Factor (LOF)
- **Principio**: Compara densidad local con densidad de vecinos
- **Parámetros**: `n_neighbors`, `contamination`
- **Ventajas**: Detecta anomalías locales
- **Uso**: Encontrar partidos con comportamiento atípico

#### 3.3 One-Class SVM
- **Principio**: Aprende frontera de decisión para datos normales
- **Parámetros**: `nu` (proporción de outliers), `kernel`, `gamma`
- **Ventajas**: Flexible con diferentes kernels
- **Uso**: Detectar partidos fuera del comportamiento normal

#### 3.4 Autoencoders
- **Principio**: Red neuronal que aprende representación comprimida
- **Parámetros**: `contamination`, `epochs`, `batch_size`
- **Ventajas**: Captura relaciones no lineales complejas
- **Uso**: Detectar anomalías complejas en datos de alta dimensión

### Interpretación de Resultados

- **Anomalías detectadas**: Partidos con estadísticas inusuales
- **Posibles causas**:
  - Lesiones de jugadores clave
  - Condiciones especiales (playoffs, temporada regular)
  - Errores en datos
  - Eventos extraordinarios

## 4. Reglas de Asociación

### Objetivo
Descubrir relaciones y patrones frecuentes entre características.

### Algoritmos Implementados

#### 4.1 Apriori Algorithm
- **Principio**: Genera itemsets frecuentes de forma incremental
- **Parámetros**: `min_support`, `metric`, `min_threshold`
- **Ventajas**: Clásico y bien entendido
- **Desventajas**: Puede ser lento para datasets grandes

#### 4.2 FP-Growth
- **Principio**: Usa estructura de árbol (FP-tree) para encontrar itemsets
- **Parámetros**: `min_support`, `metric`, `min_threshold`
- **Ventajas**: Más eficiente que Apriori
- **Uso**: Mismo propósito que Apriori pero más rápido

### Métricas

#### Support (Soporte)
- **Definición**: Frecuencia con que aparece un itemset
- **Fórmula**: P(A ∪ B)
- **Uso**: Filtrar itemsets poco frecuentes

#### Confidence (Confianza)
- **Definición**: Probabilidad de B dado A
- **Fórmula**: P(B|A) = P(A ∪ B) / P(A)
- **Uso**: Medir fuerza de la regla

#### Lift (Elevación)
- **Definición**: Cuánto más probable es B cuando A ocurre
- **Fórmula**: P(B|A) / P(B)
- **Interpretación**:
  - Lift > 1: A y B están positivamente correlacionados
  - Lift = 1: A y B son independientes
  - Lift < 1: A y B están negativamente correlacionados

### Ejemplos de Reglas Encontradas

Ejemplos de reglas que podrían encontrarse:
- "Si un equipo tiene alto porcentaje de tiros libres Y alto porcentaje de rebotes, entonces tiene alta probabilidad de ganar"
- "Partidos de playoffs tienden a tener menor número de puntos totales"
- "Equipos con alto porcentaje de triples tienden a tener más asistencias"

## 5. Integración con Pipeline Supervisado

### Uso de Resultados

**Clustering:**
- Features adicionales: Etiquetas de cluster como características
- Segmentación: Entrenar modelos separados por cluster
- Análisis exploratorio: Entender estructura de datos

**Reducción Dimensional:**
- Preprocesamiento: Reducir dimensionalidad antes de entrenar modelos
- Visualización: Entender distribución de datos
- Feature engineering: Componentes principales como nuevas features

**Detección de Anomalías:**
- Limpieza: Remover o tratar anomalías antes de entrenar
- Análisis: Investigar causas de anomalías
- Monitoreo: Detectar cambios en distribución de datos

**Reglas de Asociación:**
- Feature engineering: Crear features basadas en reglas
- Interpretabilidad: Entender relaciones entre variables
- Validación: Verificar hipótesis sobre relaciones

## 6. Visualizaciones Generadas

### Clustering
- Método del codo (K-Means)
- Dendrograma (Hierarchical)
- Comparación 2D de todos los algoritmos

### Reducción Dimensional
- Varianza explicada (PCA)
- Biplot (PCA)
- Comparación 2D (PCA, t-SNE, UMAP, SVD)
- Heatmap de loadings (PCA)

### Detección de Anomalías
- Comparación 2D de todos los algoritmos
- Distribución de scores de anomalía

### Reglas de Asociación
- Tablas comparativas
- Top reglas por métrica

## 7. Métricas y Reportes

### Archivos Generados

**Métricas:**
- `clustering_comparison_table.csv`: Comparación de algoritmos de clustering
- `pca_metrics.json`: Métricas de PCA
- `anomaly_comparison_table.csv`: Comparación de detección de anomalías
- `association_rules_comparison_table.csv`: Comparación de algoritmos

**Visualizaciones:**
- `clustering_elbow_method.png`
- `clustering_dendrogram.png`
- `clustering_2d_comparison.png`
- `pca_variance_explained.png`
- `pca_biplot.png`
- `dimensionality_reduction_2d_comparison.png`
- `anomaly_detection_comparison.png`

## 8. Conclusiones

### Logros
1. ✅ Implementación completa de 4 categorías de técnicas no supervisadas
2. ✅ 15+ algoritmos implementados
3. ✅ Todas las métricas requeridas calculadas
4. ✅ Visualizaciones comprehensivas generadas
5. ✅ Integración completa con pipeline supervisado
6. ✅ Orquestación con Airflow
7. ✅ Versionado con DVC

### Aplicaciones Prácticas
- **Segmentación de partidos**: Identificar tipos de partidos
- **Reducción de ruido**: PCA para mejorar modelos supervisados
- **Detección de fraudes**: Anomalías en estadísticas
- **Descubrimiento de conocimiento**: Reglas de asociación para insights

### Próximos Pasos
1. Análisis más profundo de clusters encontrados
2. Integración de resultados en modelos supervisados
3. Dashboard interactivo con visualizaciones
4. Análisis temporal de clusters y anomalías

