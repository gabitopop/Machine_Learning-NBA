"""
Script para ejecutar pipelines usando Python directamente (sin CLI de Kedro).
Este script importa y ejecuta los pipelines programáticamente.
"""

import sys
from pathlib import Path
import time

# Agregar src al path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root / "src"))


def run_pipeline_programmatically(pipeline_name, description):
    """Ejecuta un pipeline usando la API de Kedro programáticamente."""
    print("\n" + "=" * 70)
    print(f"EJECUTANDO: {description}")
    print(f"Pipeline: {pipeline_name}")
    print("=" * 70)
    
    try:
        import os
        from kedro.framework.project import configure_project
        from kedro.framework.session import KedroSession
        
        # Cambiar al directorio del proyecto
        original_cwd = os.getcwd()
        os.chdir(project_root)
        
        try:
            configure_project("nba")
            # Crear sesión (detecta automáticamente el proyecto desde el directorio actual)
            session = KedroSession.create()
            context = session.load_context()
        finally:
            # Restaurar directorio original
            os.chdir(original_cwd)
        
        # Obtener el pipeline
        from nba.pipeline_registry import register_pipelines
        pipelines = register_pipelines()
        
        if pipeline_name not in pipelines:
            print(f"\nERROR Pipeline '{pipeline_name}' no encontrado en registro")
            print(f"Pipelines disponibles: {list(pipelines.keys())[:10]}...")
            return False
        
        pipeline = pipelines[pipeline_name]
        
        print(f"\nPipeline encontrado: {len(list(pipeline.nodes))} nodos")
        print("Iniciando ejecucion...")
        
        start_time = time.time()
        
        # Ejecutar el pipeline
        session.run(pipeline_name=pipeline_name)
        
        elapsed_time = time.time() - start_time
        
        print(f"\nOK Pipeline '{pipeline_name}' completado exitosamente")
        print(f"Tiempo de ejecucion: {elapsed_time:.2f} segundos ({elapsed_time/60:.2f} minutos)")
        
        return True
        
    except Exception as e:
        print(f"\nERROR Al ejecutar pipeline: {e}")
        import traceback
        traceback.print_exc()
        return False


def check_imports():
    """Verifica que las importaciones funcionan."""
    print("=" * 70)
    print("VERIFICACION DE IMPORTACIONES")
    print("=" * 70)
    
    try:
        import os
        from kedro.framework.project import configure_project
        from kedro.framework.session import KedroSession
        print("OK Kedro importado correctamente")
        
        # Cambiar al directorio del proyecto
        original_cwd = os.getcwd()
        os.chdir(project_root)
        
        try:
            configure_project("nba")
            print("OK Proyecto NBA configurado")
        
            from nba.pipeline_registry import register_pipelines
            pipelines = register_pipelines()
            print(f"OK Pipelines registrados: {len(pipelines)} pipelines")
            
            # Verificar pipelines de unsupervised
            unsupervised_pipelines = [
                "unsupervised_learning",
                "unsupervised_learning.clustering",
                "unsupervised_learning.dimensionality_reduction",
                "unsupervised_learning.anomaly_detection",
                "unsupervised_learning.association_rules",
            ]
            
            print("\nPipelines de unsupervised learning:")
            for name in unsupervised_pipelines:
                if name in pipelines:
                    node_count = len(list(pipelines[name].nodes))
                    print(f"  OK {name} ({node_count} nodos)")
                else:
                    print(f"  ERROR {name} - NO ENCONTRADO")
            
            return True
        finally:
            # Restaurar directorio original
            os.chdir(original_cwd)
        
    except Exception as e:
        print(f"ERROR En verificacion de importaciones: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Ejecuta todos los pipelines."""
    print("\n" + "=" * 70)
    print("EJECUCION DE PIPELINES USANDO API DE KEDRO")
    print("=" * 70)
    print("\nEste script ejecutara los pipelines usando la API de Kedro")
    print("en lugar de la CLI, lo que permite mejor control de errores.\n")
    
    # Verificar importaciones
    if not check_imports():
        print("\nERROR: No se pudieron verificar las importaciones")
        print("Asegurate de tener todas las dependencias instaladas")
        return 1
    
    # Pipelines a ejecutar
    pipelines_to_run = [
        ("unsupervised_learning.clustering", "Clustering (K-Means, DBSCAN, Hierarchical, GMM, OPTICS)"),
        ("unsupervised_learning.dimensionality_reduction", "Reduccion de Dimensionalidad (PCA, t-SNE, UMAP, SVD)"),
        ("unsupervised_learning.anomaly_detection", "Deteccion de Anomalias (Isolation Forest, LOF, One-Class SVM, Autoencoder)"),
        ("unsupervised_learning.association_rules", "Reglas de Asociacion (Apriori, FP-Growth)"),
    ]
    
    results = []
    total_start_time = time.time()
    
    for pipeline_name, description in pipelines_to_run:
        success = run_pipeline_programmatically(pipeline_name, description)
        results.append((pipeline_name, description, success))
        
        # Pausa entre pipelines
        if success:
            print("\nEsperando 2 segundos antes del siguiente pipeline...")
            time.sleep(2)
    
    total_elapsed = time.time() - total_start_time
    
    # Resumen final
    print("\n" + "=" * 70)
    print("RESUMEN DE EJECUCION")
    print("=" * 70)
    
    passed = sum(1 for _, _, success in results if success)
    total = len(results)
    
    print(f"\nTiempo total de ejecucion: {total_elapsed:.2f} segundos ({total_elapsed/60:.2f} minutos)")
    print(f"\nResultados por pipeline:")
    
    for pipeline_name, description, success in results:
        status = "OK" if success else "ERROR"
        print(f"  {status} - {pipeline_name}")
        print(f"         {description}")
    
    print(f"\n{'=' * 70}")
    print(f"Total: {passed}/{total} pipelines ejecutados exitosamente")
    print(f"{'=' * 70}\n")
    
    if passed == total:
        print("TODOS LOS PIPELINES SE EJECUTARON EXITOSAMENTE")
        return 0
    else:
        print("ALGUNOS PIPELINES FALLARON")
        print("Revisa los errores arriba para mas detalles.")
        return 1


if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)

