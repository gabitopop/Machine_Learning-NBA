"""
Script para realizar pruebas reales de Docker del proyecto NBA.
Verifica que los contenedores se construyan y ejecuten correctamente.
"""

import subprocess
import sys
import time
from pathlib import Path

project_root = Path(__file__).parent


def run_command(cmd, description, check=True, timeout=300):
    """Ejecuta un comando y muestra el resultado."""
    print("\n" + "=" * 70)
    print(f"EJECUTANDO: {description}")
    print("=" * 70)
    print(f"Comando: {' '.join(cmd) if isinstance(cmd, list) else cmd}")
    
    try:
        result = subprocess.run(
            cmd,
            shell=isinstance(cmd, str),
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=project_root
        )
        
        if result.returncode == 0:
            print(f"\nOK {description} completado exitosamente")
            if result.stdout:
                print("\nSalida (ultimas 20 lineas):")
                lines = result.stdout.split('\n')
                for line in lines[-20:]:
                    if line.strip():
                        print(f"  {line}")
            return True, result.stdout
        else:
            print(f"\nERROR {description} fallo")
            print(f"Codigo de salida: {result.returncode}")
            if result.stderr:
                print("\nErrores:")
                error_lines = result.stderr.split('\n')[-30:]
                for line in error_lines:
                    if line.strip():
                        print(f"  {line}")
            if result.stdout:
                print("\nSalida:")
                output_lines = result.stdout.split('\n')[-10:]
                for line in output_lines:
                    if line.strip():
                        print(f"  {line}")
            if check:
                return False, result.stderr
            else:
                return True, result.stdout
                
    except subprocess.TimeoutExpired:
        print(f"\nTIMEOUT {description} tardo mas de {timeout} segundos")
        return False, "Timeout"
    except FileNotFoundError:
        print(f"\nERROR Comando no encontrado")
        print("Asegurate de tener Docker instalado y en el PATH")
        return False, "Command not found"
    except Exception as e:
        print(f"\nERROR Excepcion: {e}")
        import traceback
        traceback.print_exc()
        return False, str(e)


def check_docker_installed():
    """Verifica que Docker este instalado."""
    print("=" * 70)
    print("VERIFICACION DE DOCKER")
    print("=" * 70)
    
    success, output = run_command(
        ["docker", "--version"],
        "Verificar version de Docker",
        check=False
    )
    
    if not success:
        print("\nERROR: Docker no esta instalado o no esta en el PATH")
        return False
    
    success, output = run_command(
        ["docker", "compose", "version"],
        "Verificar version de Docker Compose",
        check=False
    )
    
    if not success:
        print("\nADVERTENCIA: Docker Compose no disponible")
        print("Intentando con 'docker-compose'...")
        success, output = run_command(
            ["docker-compose", "--version"],
            "Verificar version de docker-compose",
            check=False
        )
    
    return success


def check_docker_files():
    """Verifica que existan los archivos de Docker necesarios."""
    print("\n" + "=" * 70)
    print("VERIFICACION DE ARCHIVOS DOCKER")
    print("=" * 70)
    
    required_files = [
        "Dockerfile",
        "docker-compose.yml",
    ]
    
    all_exist = True
    for file_name in required_files:
        file_path = project_root / file_name
        if file_path.exists():
            print(f"OK {file_name} encontrado")
        else:
            print(f"ERROR {file_name} NO encontrado")
            all_exist = False
    
    return all_exist


def test_docker_build():
    """Prueba construir la imagen de Docker."""
    print("\n" + "=" * 70)
    print("PRUEBA: CONSTRUCCION DE IMAGEN DOCKER")
    print("=" * 70)
    
    # Limpiar imágenes anteriores si existen
    print("\nLimpiando imagenes anteriores...")
    run_command(
        ["docker", "rmi", "-f", "nba-ml:latest"],
        "Eliminar imagen anterior (si existe)",
        check=False
    )
    
    # Construir la imagen
    success, output = run_command(
        ["docker", "build", "-t", "nba-ml:latest", "."],
        "Construir imagen Docker",
        check=False,
        timeout=600  # 10 minutos para construir
    )
    
    if success:
        # Verificar que la imagen se creo
        success2, output2 = run_command(
            ["docker", "images", "nba-ml:latest"],
            "Verificar imagen creada",
            check=False
        )
        return success2
    else:
        return False


def test_docker_compose_config():
    """Prueba la configuracion de docker-compose."""
    print("\n" + "=" * 70)
    print("PRUEBA: CONFIGURACION DOCKER COMPOSE")
    print("=" * 70)
    
    # Verificar configuracion
    success, output = run_command(
        ["docker", "compose", "config"],
        "Validar configuracion docker-compose.yml",
        check=False
    )
    
    if not success:
        # Intentar con docker-compose (sin espacio)
        success, output = run_command(
            ["docker-compose", "config"],
            "Validar configuracion docker-compose.yml (alternativa)",
            check=False
        )
    
    return success


def test_docker_compose_up():
    """Prueba levantar los servicios con docker-compose."""
    print("\n" + "=" * 70)
    print("PRUEBA: LEVANTAR SERVICIOS DOCKER COMPOSE")
    print("=" * 70)
    
    # Primero, detener servicios anteriores si existen
    print("\nDeteniendo servicios anteriores (si existen)...")
    run_command(
        ["docker", "compose", "down"],
        "Detener servicios anteriores",
        check=False
    )
    
    # Levantar servicios en modo detached
    success, output = run_command(
        ["docker", "compose", "up", "-d"],
        "Levantar servicios en modo detached",
        check=False,
        timeout=300
    )
    
    if success:
        # Esperar un poco para que los servicios inicien
        print("\nEsperando 10 segundos para que los servicios inicien...")
        time.sleep(10)
        
        # Verificar estado de los servicios
        success2, output2 = run_command(
            ["docker", "compose", "ps"],
            "Verificar estado de servicios",
            check=False
        )
        
        return success2
    else:
        return False


def test_docker_compose_logs():
    """Prueba ver los logs de los servicios."""
    print("\n" + "=" * 70)
    print("PRUEBA: LOGS DE SERVICIOS")
    print("=" * 70)
    
    success, output = run_command(
        ["docker", "compose", "logs", "--tail=50"],
        "Ver logs de servicios (ultimas 50 lineas)",
        check=False
    )
    
    return success


def test_docker_compose_down():
    """Prueba detener los servicios."""
    print("\n" + "=" * 70)
    print("PRUEBA: DETENER SERVICIOS")
    print("=" * 70)
    
    success, output = run_command(
        ["docker", "compose", "down"],
        "Detener servicios",
        check=False
    )
    
    return success


def main():
    """Ejecuta todas las pruebas de Docker."""
    print("\n" + "=" * 70)
    print("PRUEBAS REALES DE DOCKER - PROYECTO NBA")
    print("=" * 70)
    print("\nEste script ejecutara pruebas reales de Docker para verificar")
    print("que todo esta funcionando correctamente.\n")
    
    results = []
    
    # 1. Verificar Docker instalado
    if not check_docker_installed():
        print("\nERROR: Docker no esta disponible")
        print("Por favor instala Docker antes de continuar")
        return 1
    results.append(("Docker instalado", True))
    
    # 2. Verificar archivos Docker
    if not check_docker_files():
        print("\nERROR: Faltan archivos de Docker necesarios")
        return 1
    results.append(("Archivos Docker", True))
    
    # 3. Probar configuracion docker-compose
    config_ok = test_docker_compose_config()
    results.append(("Configuracion docker-compose", config_ok))
    
    # 4. Probar construccion de imagen
    build_ok = test_docker_build()
    results.append(("Construccion imagen Docker", build_ok))
    
    # 5. Probar levantar servicios
    if build_ok:
        up_ok = test_docker_compose_up()
        results.append(("Levantar servicios", up_ok))
        
        # 6. Ver logs
        if up_ok:
            logs_ok = test_docker_compose_logs()
            results.append(("Ver logs", logs_ok))
        
        # 7. Detener servicios
        down_ok = test_docker_compose_down()
        results.append(("Detener servicios", down_ok))
    else:
        results.append(("Levantar servicios", False))
        results.append(("Ver logs", False))
        results.append(("Detener servicios", False))
    
    # Resumen final
    print("\n" + "=" * 70)
    print("RESUMEN DE PRUEBAS")
    print("=" * 70)
    
    passed = sum(1 for _, success in results if success)
    total = len(results)
    
    print(f"\nResultados:")
    for test_name, success in results:
        status = "OK" if success else "ERROR"
        print(f"  {status} - {test_name}")
    
    print(f"\n{'=' * 70}")
    print(f"Total: {passed}/{total} pruebas exitosas")
    print(f"{'=' * 70}\n")
    
    if passed == total:
        print("TODAS LAS PRUEBAS DE DOCKER PASARON")
        print("\nEl proyecto esta listo para ejecutarse en Docker.")
        return 0
    else:
        print("ALGUNAS PRUEBAS FALLARON")
        print("Revisa los errores arriba para mas detalles.")
        return 1


if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)

