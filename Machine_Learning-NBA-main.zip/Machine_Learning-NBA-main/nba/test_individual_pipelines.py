"""
Script simplificado para probar que los pipelines individuales de unsupervised learning
pueden ejecutarse por separado usando tags de Kedro.
"""

import sys
from pathlib import Path

# Agregar el directorio src al path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root / "src"))


def test_dag_structure():
    """Verifica que el DAG tiene tasks separados."""
    print("=" * 60)
    print("TEST: Verificacion de Estructura del DAG de Airflow")
    print("=" * 60)
    
    dag_file = project_root / "airflow" / "dags" / "nba_ml_pipeline.py"
    
    if not dag_file.exists():
        print(f"ERROR: Archivo DAG no encontrado: {dag_file}")
        return False
    
    with open(dag_file, 'r', encoding='utf-8') as f:
        dag_content = f.read()
    
    # Verificar tasks
    required_tasks = [
        "clustering_task",
        "dimensionality_reduction_task",
        "anomaly_detection_task",
        "association_rules_task",
    ]
    
    print("\nTasks en el DAG:")
    all_found = True
    for task_name in required_tasks:
        if f"task_id='{task_name}'" in dag_content:
            print(f"  OK {task_name}")
        else:
            print(f"  X {task_name} - NO ENCONTRADO")
            all_found = False
    
    # Verificar comandos
    print("\nComandos Kedro en cada task:")
    commands = [
        ("unsupervised_learning.clustering", "clustering_task"),
        ("unsupervised_learning.dimensionality_reduction", "dimensionality_reduction_task"),
        ("unsupervised_learning.anomaly_detection", "anomaly_detection_task"),
        ("unsupervised_learning.association_rules", "association_rules_task"),
    ]
    
    all_commands_ok = True
    for pipeline_name, task_name in commands:
        if f"--pipeline {pipeline_name}" in dag_content:
            print(f"  OK {task_name}: kedro run --pipeline {pipeline_name}")
        else:
            print(f"  X {task_name}: comando no encontrado")
            all_commands_ok = False
    
    # Verificar dependencias
    print("\nDependencias:")
    if ">>" in dag_content or "set_downstream" in dag_content:
        print("  OK Dependencias definidas entre tasks")
        # Verificar que los tasks de unsupervised están conectados
        if "clustering_task" in dag_content and "dimensionality_reduction_task" in dag_content:
            print("  OK Tasks de unsupervised learning presentes en dependencias")
    else:
        print("  X Dependencias no encontradas")
        all_commands_ok = False
    
    return all_found and all_commands_ok


def test_kedro_pipeline_names():
    """Verifica que los nombres de pipelines son correctos según la estructura."""
    print("\n" + "=" * 60)
    print("TEST: Verificacion de Nombres de Pipelines")
    print("=" * 60)
    
    # Verificar estructura de archivos
    pipeline_dirs = [
        "src/nba/pipelines/unsupervised_learning/clustering",
        "src/nba/pipelines/unsupervised_learning/dimensionality_reduction",
        "src/nba/pipelines/unsupervised_learning/anomaly_detection",
        "src/nba/pipelines/unsupervised_learning/association_rules",
    ]
    
    print("\nDirectorios de pipelines:")
    all_exist = True
    for pipeline_dir in pipeline_dirs:
        dir_path = project_root / pipeline_dir
        if dir_path.exists():
            print(f"  OK {pipeline_dir}")
            # Verificar que tiene pipeline.py
            pipeline_file = dir_path / "pipeline.py"
            if pipeline_file.exists():
                print(f"    OK pipeline.py existe")
            else:
                print(f"    X pipeline.py no encontrado")
                all_exist = False
        else:
            print(f"  X {pipeline_dir} - NO EXISTE")
            all_exist = False
    
    return all_exist


def test_catalog_entries():
    """Verifica entradas clave en el catálogo."""
    print("\n" + "=" * 60)
    print("TEST: Verificacion de Entradas en Catalogo")
    print("=" * 60)
    
    catalog_file = project_root / "conf" / "base" / "catalog.yml"
    
    if not catalog_file.exists():
        print(f"ERROR: Archivo de catalogo no encontrado")
        return False
    
    with open(catalog_file, 'r', encoding='utf-8') as f:
        catalog_content = f.read()
    
    required_entries = [
        "clustering_data",
        "kmeans_model",
        "dbscan_model",
        "pca_model",
        "pca_metrics",
        "isolation_forest_model",
        "apriori_rules",
    ]
    
    print("\nEntradas en catalogo:")
    all_found = True
    for entry in required_entries:
        if entry in catalog_content:
            print(f"  OK {entry}")
        else:
            print(f"  X {entry} - NO ENCONTRADO")
            all_found = False
    
    return all_found


def test_parameters_file():
    """Verifica que existe el archivo de parámetros."""
    print("\n" + "=" * 60)
    print("TEST: Verificacion de Archivo de Parametros")
    print("=" * 60)
    
    params_file = project_root / "conf" / "base" / "parameters_unsupervised.yml"
    
    if not params_file.exists():
        print(f"ERROR: Archivo de parametros no encontrado")
        return False
    
    with open(params_file, 'r', encoding='utf-8') as f:
        params_content = f.read()
    
    required_sections = [
        "clustering:",
        "dimensionality_reduction:",
        "anomaly_detection:",
        "association_rules:",
    ]
    
    print("\nSecciones en parametros:")
    all_found = True
    for section in required_sections:
        if section in params_content:
            print(f"  OK {section}")
        else:
            print(f"  X {section} - NO ENCONTRADO")
            all_found = False
    
    return all_found


def show_execution_examples():
    """Muestra ejemplos de cómo ejecutar los pipelines individualmente."""
    print("\n" + "=" * 60)
    print("EJEMPLOS DE EJECUCION")
    print("=" * 60)
    
    print("\nPara ejecutar cada pipeline individualmente desde la terminal:")
    print("\n1. Clustering:")
    print("   kedro run --pipeline unsupervised_learning.clustering")
    print("   O usando tags:")
    print("   kedro run --tags clustering")
    
    print("\n2. Reduccion de Dimensionalidad:")
    print("   kedro run --pipeline unsupervised_learning.dimensionality_reduction")
    print("   O usando tags:")
    print("   kedro run --tags dimensionality_reduction")
    
    print("\n3. Deteccion de Anomalias:")
    print("   kedro run --pipeline unsupervised_learning.anomaly_detection")
    print("   O usando tags:")
    print("   kedro run --tags anomaly_detection")
    
    print("\n4. Reglas de Asociacion:")
    print("   kedro run --pipeline unsupervised_learning.association_rules")
    print("   O usando tags:")
    print("   kedro run --tags association_rules")
    
    print("\n5. Pipeline completo de unsupervised learning:")
    print("   kedro run --pipeline unsupervised_learning")
    
    print("\n" + "=" * 60)
    print("NOTA: Los nombres exactos de pipelines dependen de como")
    print("Kedro los registra. Si los nombres con punto no funcionan,")
    print("puedes usar tags para ejecutar sub-pipelines.")
    print("=" * 60)


def main():
    """Ejecuta todas las pruebas."""
    print("\n" + "=" * 60)
    print("PRUEBAS DE FUNCIONALIDAD - TASKS SEPARADOS")
    print("=" * 60)
    print("\nEste script valida que los tasks separados de unsupervised learning")
    print("estan correctamente configurados en el DAG de Airflow.\n")
    
    tests = [
        ("Estructura DAG Airflow", test_dag_structure),
        ("Nombres de Pipelines", test_kedro_pipeline_names),
        ("Entradas en Catalogo", test_catalog_entries),
        ("Archivo de Parametros", test_parameters_file),
    ]
    
    results = []
    
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"\nERROR en test '{test_name}': {e}")
            results.append((test_name, False))
    
    # Mostrar ejemplos
    show_execution_examples()
    
    # Resumen final
    print("\n" + "=" * 60)
    print("RESUMEN DE PRUEBAS")
    print("=" * 60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "PASS" if result else "FAIL"
        print(f"{status} - {test_name}")
    
    print(f"\n{'=' * 60}")
    print(f"Total: {passed}/{total} pruebas pasadas")
    print(f"{'=' * 60}\n")
    
    if passed == total:
        print("TODAS LAS PRUEBAS PASARON")
        print("\nLos tasks separados estan correctamente configurados.")
        print("El DAG de Airflow tiene 4 tasks independientes:")
        print("  - clustering_task")
        print("  - dimensionality_reduction_task")
        print("  - anomaly_detection_task")
        print("  - association_rules_task")
        return 0
    else:
        print("ALGUNAS PRUEBAS FALLARON")
        print("Revisa los resultados arriba para mas detalles.")
        return 1


if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)

