"""
Script para verificar la configuración de Docker sin ejecutarlo.
Analiza los archivos Dockerfile y docker-compose.yml para detectar problemas.
"""

import sys
from pathlib import Path
import re

project_root = Path(__file__).parent


def check_dockerfile():
    """Verifica que el Dockerfile sea válido."""
    print("=" * 70)
    print("VERIFICACION DE Dockerfile")
    print("=" * 70)
    
    dockerfile_path = project_root / "Dockerfile"
    if not dockerfile_path.exists():
        print("ERROR Dockerfile no encontrado")
        return False
    
    print("OK Dockerfile encontrado")
    
    content = dockerfile_path.read_text(encoding='utf-8')
    
    # Verificar elementos esenciales
    checks = {
        "FROM": "Imagen base definida",
        "WORKDIR": "Directorio de trabajo definido",
        "COPY requirements.txt": "requirements.txt copiado",
        "RUN pip install": "Instalación de dependencias",
    }
    
    all_ok = True
    for key, description in checks.items():
        if key in content:
            print(f"  OK {description}")
        else:
            print(f"  ERROR {description} - NO ENCONTRADO")
            all_ok = False
    
    # Verificar que se copian los archivos necesarios
    required_files = ["requirements.txt", "src/", "conf/"]
    for file_pattern in required_files:
        if file_pattern in content:
            print(f"  OK Copia de {file_pattern}")
        else:
            print(f"  ADVERTENCIA {file_pattern} no se copia explícitamente")
    
    return all_ok


def check_docker_compose():
    """Verifica que docker-compose.yml sea válido."""
    print("\n" + "=" * 70)
    print("VERIFICACION DE docker-compose.yml")
    print("=" * 70)
    
    compose_path = project_root / "docker-compose.yml"
    if not compose_path.exists():
        print("ERROR docker-compose.yml no encontrado")
        return False
    
    print("OK docker-compose.yml encontrado")
    
    content = compose_path.read_text(encoding='utf-8')
    
    # Verificar servicios
    services = ["nba-ml", "nba-jupyter", "nba-airflow"]
    found_services = []
    
    for service in services:
        if f"{service}:" in content:
            print(f"  OK Servicio '{service}' definido")
            found_services.append(service)
        else:
            print(f"  ERROR Servicio '{service}' NO definido")
    
    # Verificar volúmenes
    if "volumes:" in content:
        print("  OK Volúmenes definidos")
    else:
        print("  ADVERTENCIA No se encontraron volúmenes")
    
    # Verificar puertos
    if "ports:" in content:
        print("  OK Puertos expuestos")
    else:
        print("  ADVERTENCIA No se encontraron puertos expuestos")
    
    return len(found_services) > 0


def check_dockerfile_airflow():
    """Verifica que Dockerfile.airflow sea válido."""
    print("\n" + "=" * 70)
    print("VERIFICACION DE Dockerfile.airflow")
    print("=" * 70)
    
    dockerfile_path = project_root / "Dockerfile.airflow"
    if not dockerfile_path.exists():
        print("ERROR Dockerfile.airflow no encontrado")
        return False
    
    print("OK Dockerfile.airflow encontrado")
    
    content = dockerfile_path.read_text(encoding='utf-8')
    
    # Verificar elementos esenciales
    checks = {
        "FROM apache/airflow": "Imagen base de Airflow",
        "requirements.txt": "requirements.txt copiado",
        "pip install": "Instalación de dependencias",
    }
    
    all_ok = True
    for key, description in checks.items():
        if key in content:
            print(f"  OK {description}")
        else:
            print(f"  ERROR {description} - NO ENCONTRADO")
            all_ok = False
    
    return all_ok


def check_required_files():
    """Verifica que existan los archivos necesarios para Docker."""
    print("\n" + "=" * 70)
    print("VERIFICACION DE ARCHIVOS REQUERIDOS")
    print("=" * 70)
    
    required_files = [
        "requirements.txt",
        "pyproject.toml",
        "entrypoint.sh",
        "src/nba/__init__.py",
        "conf/base/catalog.yml",
        "conf/base/parameters.yml",
    ]
    
    all_exist = True
    for file_path in required_files:
        full_path = project_root / file_path
        if full_path.exists():
            print(f"  OK {file_path}")
        else:
            print(f"  ERROR {file_path} NO encontrado")
            all_exist = False
    
    return all_exist


def check_entrypoint():
    """Verifica que entrypoint.sh sea válido."""
    print("\n" + "=" * 70)
    print("VERIFICACION DE entrypoint.sh")
    print("=" * 70)
    
    entrypoint_path = project_root / "entrypoint.sh"
    if not entrypoint_path.exists():
        print("ERROR entrypoint.sh no encontrado")
        return False
    
    print("OK entrypoint.sh encontrado")
    
    content = entrypoint_path.read_text(encoding='utf-8')
    
    # Verificar que tenga shebang
    if content.startswith("#!/bin/bash") or content.startswith("#!/bin/sh"):
        print("  OK Shebang presente")
    else:
        print("  ADVERTENCIA Shebang no encontrado")
    
    # Verificar que sea ejecutable (en sistemas Unix)
    import os
    if os.name != 'nt':  # No Windows
        if os.access(entrypoint_path, os.X_OK):
            print("  OK Archivo es ejecutable")
        else:
            print("  ADVERTENCIA Archivo no es ejecutable")
    
    return True


def generate_docker_commands():
    """Genera comandos Docker para ejecutar manualmente."""
    print("\n" + "=" * 70)
    print("COMANDOS DOCKER PARA EJECUTAR MANUALMENTE")
    print("=" * 70)
    
    commands = [
        ("Verificar Docker instalado", "docker --version"),
        ("Verificar Docker Compose", "docker compose version"),
        ("Construir imagen principal", "docker build -t nba-ml:latest ."),
        ("Validar docker-compose.yml", "docker compose config"),
        ("Construir todos los servicios", "docker compose build"),
        ("Levantar servicios", "docker compose up -d"),
        ("Ver logs", "docker compose logs -f"),
        ("Ver estado de servicios", "docker compose ps"),
        ("Detener servicios", "docker compose down"),
        ("Ejecutar pipeline en contenedor", "docker compose run --rm nba-ml kedro run"),
        ("Abrir Jupyter", "docker compose up nba-jupyter"),
        ("Abrir Airflow UI", "Abrir navegador en http://localhost:8080"),
    ]
    
    print("\nComandos para ejecutar en el directorio del proyecto:\n")
    for description, command in commands:
        print(f"# {description}")
        print(f"{command}\n")


def main():
    """Ejecuta todas las verificaciones."""
    print("\n" + "=" * 70)
    print("VERIFICACION DE CONFIGURACION DOCKER - PROYECTO NBA")
    print("=" * 70)
    print("\nEste script verifica la configuracion de Docker sin ejecutarlo.")
    print("Para pruebas reales, necesitas tener Docker instalado.\n")
    
    results = []
    
    # Verificaciones
    results.append(("Dockerfile", check_dockerfile()))
    results.append(("docker-compose.yml", check_docker_compose()))
    results.append(("Dockerfile.airflow", check_dockerfile_airflow()))
    results.append(("Archivos requeridos", check_required_files()))
    results.append(("entrypoint.sh", check_entrypoint()))
    
    # Resumen
    print("\n" + "=" * 70)
    print("RESUMEN DE VERIFICACIONES")
    print("=" * 70)
    
    passed = sum(1 for _, success in results if success)
    total = len(results)
    
    print(f"\nResultados:")
    for test_name, success in results:
        status = "OK" if success else "ERROR"
        print(f"  {status} - {test_name}")
    
    print(f"\n{'=' * 70}")
    print(f"Total: {passed}/{total} verificaciones exitosas")
    print(f"{'=' * 70}\n")
    
    # Generar comandos
    generate_docker_commands()
    
    if passed == total:
        print("\nTODAS LAS VERIFICACIONES PASARON")
        print("La configuracion de Docker parece correcta.")
        print("Para ejecutar pruebas reales, instala Docker y ejecuta los comandos arriba.")
        return 0
    else:
        print("\nALGUNAS VERIFICACIONES FALLARON")
        print("Revisa los errores arriba y corrige la configuracion.")
        return 1


if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)

