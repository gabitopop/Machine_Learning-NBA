"""
Script de prueba para verificar que los tasks separados de Airflow funcionan correctamente.
Prueba los comandos que se ejecutarán en cada task.
"""

import subprocess
import sys
import os
from pathlib import Path

# Colores para output
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
RESET = '\033[0m'

def print_header(text):
    """Imprime un encabezado formateado"""
    print(f"\n{BLUE}{'='*70}{RESET}")
    print(f"{BLUE}{text}{RESET}")
    print(f"{BLUE}{'='*70}{RESET}\n")

def print_success(text):
    """Imprime mensaje de éxito"""
    print(f"{GREEN}[OK] {text}{RESET}")

def print_error(text):
    """Imprime mensaje de error"""
    print(f"{RED}[ERROR] {text}{RESET}")

def print_warning(text):
    """Imprime mensaje de advertencia"""
    print(f"{YELLOW}[WARN] {text}{RESET}")

def print_info(text):
    """Imprime mensaje informativo"""
    print(f"{BLUE}[INFO] {text}{RESET}")

def check_kedro_installed():
    """Verifica si Kedro está instalado"""
    try:
        result = subprocess.run(
            ['kedro', '--version'],
            capture_output=True,
            text=True,
            timeout=10
        )
        if result.returncode == 0:
            print_success(f"Kedro instalado: {result.stdout.strip()}")
            return True
        else:
            print_error("Kedro no está instalado o no está en PATH")
            return False
    except FileNotFoundError:
        print_error("Kedro no está instalado o no está en PATH")
        return False
    except subprocess.TimeoutExpired:
        print_error("Timeout al verificar Kedro")
        return False

def check_project_structure():
    """Verifica que estamos en el directorio correcto del proyecto"""
    project_root = Path.cwd()
    
    required_files = [
        'pyproject.toml',
        'src/nba/pipelines/unsupervised_learning',
        'conf/base/parameters_unsupervised.yml',
        'conf/base/catalog.yml'
    ]
    
    all_present = True
    for file_path in required_files:
        full_path = project_root / file_path
        if not full_path.exists():
            print_error(f"Archivo/directorio no encontrado: {file_path}")
            all_present = False
        else:
            print_success(f"Encontrado: {file_path}")
    
    return all_present

def list_kedro_pipelines():
    """Lista todos los pipelines disponibles en Kedro"""
    try:
        result = subprocess.run(
            ['kedro', 'pipeline', 'list'],
            capture_output=True,
            text=True,
            timeout=30,
            cwd=Path.cwd()
        )
        
        if result.returncode == 0:
            print_info("Pipelines disponibles en Kedro:")
            print(result.stdout)
            return result.stdout
        else:
            print_error(f"Error al listar pipelines: {result.stderr}")
            return None
    except Exception as e:
        print_error(f"Error al ejecutar kedro pipeline list: {e}")
        return None

def test_pipeline_command(pipeline_name, description):
    """Prueba si un comando de pipeline es válido (dry-run)"""
    print_info(f"Probando: {description}")
    print(f"   Comando: kedro run --pipeline {pipeline_name} --dry-run")
    
    try:
        result = subprocess.run(
            ['kedro', 'run', '--pipeline', pipeline_name, '--dry-run'],
            capture_output=True,
            text=True,
            timeout=60,
            cwd=Path.cwd()
        )
        
        if result.returncode == 0:
            # Contar nodos que se ejecutarían
            node_count = result.stdout.count('node(') or result.stdout.count('Node(')
            if node_count > 0:
                print_success(f"Pipeline válido: {pipeline_name}")
                print(f"   Nodos encontrados: {node_count}")
                return True
            else:
                print_warning(f"Pipeline válido pero sin nodos: {pipeline_name}")
                return True
        else:
            print_error(f"Pipeline inválido o no encontrado: {pipeline_name}")
            print(f"   Error: {result.stderr[:200]}")
            return False
    except subprocess.TimeoutExpired:
        print_error(f"Timeout al probar pipeline: {pipeline_name}")
        return False
    except Exception as e:
        print_error(f"Error al probar pipeline {pipeline_name}: {e}")
        return False

def test_airflow_dag_syntax():
    """Verifica la sintaxis del DAG de Airflow"""
    dag_file = Path('airflow/dags/nba_ml_pipeline.py')
    
    if not dag_file.exists():
        print_error(f"DAG no encontrado: {dag_file}")
        return False
    
    try:
        # Intentar compilar el archivo Python
        with open(dag_file, 'r', encoding='utf-8') as f:
            code = f.read()
            compile(code, str(dag_file), 'exec')
        
        print_success("Sintaxis del DAG correcta")
        
        # Verificar que los tasks están definidos
        required_tasks = [
            'clustering_task',
            'dimensionality_reduction_task',
            'anomaly_detection_task',
            'association_rules_task'
        ]
        
        tasks_found = []
        for task in required_tasks:
            if task in code:
                tasks_found.append(task)
                print_success(f"Task encontrado: {task}")
            else:
                print_error(f"Task no encontrado: {task}")
        
        if len(tasks_found) == len(required_tasks):
            return True
        else:
            print_warning(f"Solo {len(tasks_found)}/{len(required_tasks)} tasks encontrados")
            return False
            
    except SyntaxError as e:
        print_error(f"Error de sintaxis en DAG: {e}")
        return False
    except Exception as e:
        print_error(f"Error al verificar DAG: {e}")
        return False

def main():
    """Ejecuta todas las pruebas"""
    print_header("PRUEBAS DE FUNCIONALIDAD - TASKS SEPARADOS AIRFLOW")
    
    # Cambiar al directorio del proyecto si es necesario
    project_root = Path(__file__).parent
    if (project_root / 'pyproject.toml').exists():
        os.chdir(project_root)
        print_info(f"Directorio del proyecto: {project_root}")
    else:
        print_error("No se encontró pyproject.toml. Asegúrate de ejecutar desde el directorio nba/")
        return 1
    
    results = []
    
    # Test 1: Verificar Kedro
    print_header("Test 1: Verificar Instalación de Kedro")
    results.append(("Kedro Instalado", check_kedro_installed()))
    
    # Test 2: Verificar Estructura del Proyecto
    print_header("Test 2: Verificar Estructura del Proyecto")
    results.append(("Estructura del Proyecto", check_project_structure()))
    
    # Test 3: Listar Pipelines
    print_header("Test 3: Listar Pipelines Disponibles")
    pipeline_list = list_kedro_pipelines()
    results.append(("Listar Pipelines", pipeline_list is not None))
    
    # Test 4: Verificar Sintaxis del DAG
    print_header("Test 4: Verificar Sintaxis del DAG de Airflow")
    results.append(("Sintaxis DAG", test_airflow_dag_syntax()))
    
    # Test 5: Probar Comandos de Pipelines Individuales
    print_header("Test 5: Probar Comandos de Pipelines Individuales")
    
    pipelines_to_test = [
        ("unsupervised_learning.clustering", "Pipeline de Clustering"),
        ("unsupervised_learning.dimensionality_reduction", "Pipeline de Reducción Dimensional"),
        ("unsupervised_learning.anomaly_detection", "Pipeline de Detección de Anomalías"),
        ("unsupervised_learning.association_rules", "Pipeline de Reglas de Asociación"),
    ]
    
    pipeline_results = []
    for pipeline_name, description in pipelines_to_test:
        result = test_pipeline_command(pipeline_name, description)
        pipeline_results.append((description, result))
        results.append((description, result))
    
    # Resumen
    print_header("RESUMEN DE PRUEBAS")
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    print(f"\nPruebas Totales: {total}")
    print(f"Pruebas Exitosas: {GREEN}{passed}{RESET}")
    print(f"Pruebas Fallidas: {RED}{total - passed}{RESET}")
    
    print(f"\n{BLUE}Detalle de Pruebas:{RESET}")
    for test_name, result in results:
        status = f"{GREEN}✅ PASÓ{RESET}" if result else f"{RED}❌ FALLÓ{RESET}"
        print(f"   {status}: {test_name}")
    
    # Recomendaciones
    print_header("RECOMENDACIONES")
    
    if all(result for _, result in pipeline_results):
        print_success("Todos los pipelines individuales son válidos")
        print_info("Puedes ejecutar cada task por separado en Airflow")
    else:
        print_warning("Algunos pipelines no son válidos")
        print_info("Verifica que los sub-pipelines estén correctamente registrados")
    
    if results[3][1]:  # Sintaxis DAG
        print_success("El DAG de Airflow está correctamente configurado")
        print_info("Los tasks separados están definidos correctamente")
    else:
        print_error("El DAG tiene problemas de sintaxis o estructura")
        print_info("Revisa el archivo airflow/dags/nba_ml_pipeline.py")
    
    # Comandos de ejemplo
    print_header("COMANDOS DE EJECUCIÓN MANUAL")
    print("Para probar manualmente cada pipeline:")
    print()
    for pipeline_name, description in pipelines_to_test:
        print(f"  {BLUE}# {description}{RESET}")
        print(f"  kedro run --pipeline {pipeline_name}")
        print()
    
    return 0 if passed == total else 1

if __name__ == "__main__":
    sys.exit(main())

