# Guía de Pruebas de Docker - Proyecto NBA

Esta guía explica cómo realizar pruebas reales de Docker para verificar que todo el proyecto funciona correctamente.

## Prerequisitos

1. **Docker Desktop** instalado y ejecutándose
2. **Docker Compose** disponible (incluido en Docker Desktop)
3. Al menos **4GB de RAM** disponibles
4. **Espacio en disco** suficiente (al menos 5GB)

## Verificación de Instalación

### Windows
```powershell
# Verificar Docker
docker --version

# Verificar Docker Compose
docker compose version
```

### Linux/Mac
```bash
# Verificar Docker
docker --version

# Verificar Docker Compose
docker compose version
```

## Estructura de Servicios Docker

El proyecto incluye 3 servicios principales:

1. **nba-ml**: Contenedor principal para ejecutar pipelines de Kedro
2. **nba-jupyter**: Servidor Jupyter para notebooks (puerto 8888)
3. **nba-airflow**: Servidor Airflow para orquestación (puerto 8080)

## Pruebas Paso a Paso

### 1. Verificar Configuración (Sin Ejecutar)

```bash
cd nba
python test_docker_config.py
```

Este script verifica que todos los archivos Docker estén correctamente configurados.

### 2. Construir Imágenes Docker

```bash
# Construir todas las imágenes
docker compose build

# O construir una imagen específica
docker build -t nba-ml:latest .
```

**Tiempo estimado**: 5-10 minutos (primera vez)

### 3. Validar Configuración docker-compose.yml

```bash
docker compose config
```

Este comando valida la sintaxis del archivo `docker-compose.yml` sin ejecutar nada.

### 4. Levantar Servicios

```bash
# Levantar todos los servicios en modo detached
docker compose up -d

# Ver logs en tiempo real
docker compose logs -f

# Ver logs de un servicio específico
docker compose logs -f nba-ml
docker compose logs -f nba-airflow
docker compose logs -f nba-jupyter
```

### 5. Verificar Estado de Servicios

```bash
# Ver estado de todos los servicios
docker compose ps

# Ver información detallada
docker compose ps -a
```

### 6. Ejecutar Pipelines en Contenedor

```bash
# Ejecutar pipeline completo
docker compose run --rm nba-ml kedro run

# Ejecutar pipeline específico
docker compose run --rm nba-ml kedro run --pipeline unsupervised_learning.clustering

# Ejecutar con tags
docker compose run --rm nba-ml kedro run --tags clustering
```

### 7. Acceder a Jupyter Notebooks

```bash
# Levantar servicio Jupyter
docker compose up nba-jupyter

# Acceder en navegador
# http://localhost:8888
# Token: Ver en logs con: docker compose logs nba-jupyter
```

### 8. Acceder a Airflow UI

```bash
# Airflow debería estar corriendo en:
# http://localhost:8080
# Usuario: admin
# Contraseña: admin
```

### 9. Verificar Volúmenes

Los siguientes directorios están montados como volúmenes:

- `./data` → `/app/data` (datos del proyecto)
- `./metrics` → `/app/metrics` (métricas)
- `./plots` → `/app/plots` (visualizaciones)
- `./logs` → `/app/logs` (logs)

Verificar que los datos se persisten:

```bash
# Ver contenido de volúmenes
docker compose exec nba-ml ls -la /app/data
docker compose exec nba-ml ls -la /app/metrics
```

### 10. Detener Servicios

```bash
# Detener servicios (mantiene contenedores)
docker compose stop

# Detener y eliminar contenedores
docker compose down

# Detener y eliminar contenedores + volúmenes
docker compose down -v
```

## Pruebas Específicas

### Prueba 1: Construcción de Imagen

```bash
docker build -t nba-ml:test .
```

**Verificar**:
- ✅ Imagen se construye sin errores
- ✅ Todas las dependencias se instalan
- ✅ Archivos se copian correctamente

### Prueba 2: Ejecución de Pipeline Básico

```bash
docker compose run --rm nba-ml kedro pipeline list
```

**Verificar**:
- ✅ Kedro funciona en el contenedor
- ✅ Pipelines se listan correctamente

### Prueba 3: Ejecución de Pipeline de Unsupervised Learning

```bash
docker compose run --rm nba-ml kedro run --pipeline unsupervised_learning.clustering
```

**Verificar**:
- ✅ Pipeline se ejecuta sin errores
- ✅ Modelos se generan
- ✅ Métricas se guardan

### Prueba 4: Servicio Jupyter

```bash
docker compose up nba-jupyter
```

**Verificar**:
- ✅ Jupyter inicia correctamente
- ✅ Accesible en http://localhost:8888
- ✅ Notebooks se pueden abrir

### Prueba 5: Servicio Airflow

```bash
docker compose up nba-airflow
```

**Verificar**:
- ✅ Airflow inicia correctamente
- ✅ Base de datos se inicializa
- ✅ Usuario admin se crea
- ✅ DAGs se cargan
- ✅ Accesible en http://localhost:8080

### Prueba 6: Ejecución de DAG Completo

1. Abrir Airflow UI: http://localhost:8080
2. Activar DAG: `nba_ml_pipeline`
3. Trigger DAG
4. Verificar que todos los tasks se ejecutan

**Verificar**:
- ✅ DAG se activa
- ✅ Tasks se ejecutan en orden
- ✅ Tasks de unsupervised learning funcionan
- ✅ No hay errores en logs

## Solución de Problemas

### Error: "Cannot connect to Docker daemon"

**Solución**: Asegúrate de que Docker Desktop esté ejecutándose.

### Error: "Port already in use"

**Solución**: 
```bash
# Ver qué está usando el puerto
netstat -ano | findstr :8080  # Windows
lsof -i :8080  # Linux/Mac

# Cambiar puerto en docker-compose.yml
ports:
  - "8081:8080"  # Usar puerto diferente
```

### Error: "No space left on device"

**Solución**:
```bash
# Limpiar imágenes no usadas
docker system prune -a

# Limpiar volúmenes no usados
docker volume prune
```

### Error: "Module not found" en contenedor

**Solución**: Verificar que `requirements.txt` incluya todas las dependencias.

### Error: "Permission denied" en entrypoint.sh

**Solución**:
```bash
# Hacer ejecutable (Linux/Mac)
chmod +x entrypoint.sh

# En Windows, usar Git Bash o WSL
```

## Comandos Útiles

```bash
# Ver uso de recursos
docker stats

# Entrar a contenedor en ejecución
docker compose exec nba-ml bash

# Ver logs de último minuto
docker compose logs --since 1m

# Reconstruir imagen sin cache
docker compose build --no-cache

# Ver tamaño de imágenes
docker images | grep nba

# Limpiar todo
docker compose down -v
docker system prune -a
```

## Verificación Final

Después de todas las pruebas, verificar:

- ✅ Todas las imágenes se construyen correctamente
- ✅ Todos los servicios inician sin errores
- ✅ Pipelines se ejecutan en contenedores
- ✅ Jupyter accesible y funcional
- ✅ Airflow accesible y DAGs funcionan
- ✅ Datos se persisten en volúmenes
- ✅ Logs se generan correctamente

## Notas Importantes

1. **Primera ejecución**: La primera vez que construyes las imágenes puede tardar 10-15 minutos.

2. **Memoria**: Airflow puede consumir bastante memoria. Asegúrate de tener al menos 4GB disponibles.

3. **Puertos**: Si los puertos 8080 o 8888 están en uso, cámbialos en `docker-compose.yml`.

4. **Datos**: Los datos en `./data` se montan como volúmenes, así que cualquier cambio se refleja en el contenedor.

5. **Desarrollo**: Para desarrollo activo, es mejor ejecutar los servicios en modo interactivo:
   ```bash
   docker compose up
   ```

## Scripts de Prueba Automatizados

El proyecto incluye scripts de prueba:

- `test_docker_config.py`: Verifica configuración sin ejecutar Docker
- `test_docker_real.py`: Ejecuta pruebas reales (requiere Docker)

Ejecutar:
```bash
python test_docker_config.py
python test_docker_real.py  # Requiere Docker instalado
```

