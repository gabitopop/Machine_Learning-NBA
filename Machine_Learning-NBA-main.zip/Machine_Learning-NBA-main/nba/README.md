# 🏀 NBA Machine Learning Project - Aprendizaje Supervisado y No Supervisado

[![Powered by Kedro](https://img.shields.io/badge/powered_by-kedro-ffc900?logo=kedro)](https://kedro.org)
[![Python](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![Docker](https://img.shields.io/badge/docker-ready-2496ED?logo=docker)](https://www.docker.com/)
[![Airflow](https://img.shields.io/badge/airflow-integrated-017CEE?logo=apache-airflow)](https://airflow.apache.org/)
[![DVC](https://img.shields.io/badge/dvc-versioned-945DD6?logo=dvc)](https://dvc.org/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)

## 📋 Descripción del Proyecto

Sistema completo de Machine Learning para análisis y predicción de partidos de la NBA, integrando técnicas de **aprendizaje supervisado** y **no supervisado**. El proyecto analiza más de 65,000 partidos históricos utilizando un pipeline profesional con Kedro, Airflow, DVC y Docker.

### 🎯 Objetivos

1. **Predicción de Ganadores**: Modelos de clasificación para predecir victorias locales
2. **Análisis de Patrones**: Clustering para identificar tipos de partidos y estilos de juego
3. **Reducción Dimensional**: Visualización y comprensión de datos de alta dimensión
4. **Detección de Anomalías**: Identificación de partidos inusuales
5. **Reglas de Asociación**: Descubrimiento de patrones frecuentes entre características
6. **Integración**: Uso de clustering como feature engineering para mejorar modelos supervisados

## 🏗️ Arquitectura del Proyecto

### 📁 Estructura de Pipelines

```
src/nba/pipelines/
├── data_processing/          # Limpieza y preparación de datos
├── data_science/            # Clasificación supervisada
├── regression/              # Regresión supervisada
├── unsupervised_learning/   # Aprendizaje no supervisado
│   ├── clustering/          # 5 algoritmos de clustering
│   ├── dimensionality_reduction/  # 4 técnicas de reducción
│   ├── anomaly_detection/   # 4 algoritmos de detección
│   ├── association_rules/   # 2 algoritmos de reglas
│   └── integration/         # Integración con supervisados
├── reporting/               # Visualizaciones y reportes
└── regression_reporting/    # Reportes de regresión
```

### 🔬 Técnicas Implementadas

#### Aprendizaje Supervisado
- **Clasificación**: Random Forest, Gradient Boosting, Logistic Regression, SVM, KNN, Naive Bayes
- **Regresión**: Random Forest Regressor, Gradient Boosting Regressor, Linear Regression
- **Métricas**: Accuracy, Precision, Recall, F1-Score, ROC-AUC, R², MAE, RMSE

#### Aprendizaje No Supervisado

##### 1. Clustering (5 algoritmos)
- **K-Means**: Clustering particional con método del codo
- **DBSCAN**: Clustering basado en densidad
- **Hierarchical Clustering**: Clustering jerárquico con dendrogramas
- **Gaussian Mixture Models**: Clustering probabilístico
- **OPTICS**: Alternativa a DBSCAN para densidades variables

**Métricas**: Silhouette Score, Davies-Bouldin Index, Calinski-Harabasz Index, Elbow Method

##### 2. Reducción de Dimensionalidad (4 técnicas)
- **PCA**: Análisis de componentes principales (varianza explicada, loadings, biplots)
- **t-SNE**: Visualización 2D/3D de alta dimensión
- **UMAP**: Alternativa moderna a t-SNE
- **Truncated SVD**: Para datos sparse

##### 3. Detección de Anomalías (4 algoritmos)
- **Isolation Forest**: Detección eficiente de outliers
- **Local Outlier Factor (LOF)**: Detección basada en densidad local
- **One-Class SVM**: Frontera de decisión para datos normales
- **Autoencoders**: Redes neuronales para detección compleja

##### 4. Reglas de Asociación (2 algoritmos)
- **Apriori Algorithm**: Minería de itemsets frecuentes
- **FP-Growth**: Algoritmo eficiente para reglas de asociación

**Métricas**: Support, Confidence, Lift

##### 5. Integración con Supervisados
- **Feature Engineering**: Etiquetas de cluster como features adicionales
- **Evaluación Comparativa**: Métricas con y sin clustering features
- **Análisis de Mejora**: Medición de impacto en modelos supervisados

### 📊 Análisis de Patrones por Cluster

Para cada algoritmo de clustering se genera:
- **Estadísticas Descriptivas**: Media, mediana, desviación estándar por característica
- **Perfiles de Cluster**: Características más distintivas (altas/bajas vs media global)
- **Interpretación de Negocio**: Distribución de variable objetivo por cluster
- **Etiquetado Semántico**: Etiquetas descriptivas automáticas (ej: "Alta Puntuación | Buena Defensa")

## 🚀 Instalación y Configuración

### Prerrequisitos
- Python 3.9+
- Docker y Docker Compose (opcional)
- Git

### Instalación Local

```bash
# Clonar el repositorio
git clone <repository-url>
cd Machine_Learning-NBA-main/nba

# Instalar dependencias
pip install -r requirements.txt
```

### Instalación con Docker

```bash
# Construir y ejecutar contenedores
docker-compose up --build

# Ejecutar pipeline
docker-compose exec nba-ml kedro run
```

## 🏃‍♂️ Ejecución del Proyecto

### Ejecución Local

```bash
# Pipeline completo
kedro run

# Solo aprendizaje no supervisado
kedro run --pipeline unsupervised_learning

# Solo clustering
kedro run --pipeline unsupervised_learning.clustering

# Pipeline completo con integración
kedro run --pipeline complete_ml_pipeline
```

### Ejecución con DVC

```bash
# Reproducir pipeline completo
dvc repro

# Reproducir solo unsupervised learning
dvc repro unsupervised_learning

# Ver métricas
dvc metrics show
```

### Ejecución con Airflow

1. Iniciar servicios:
```bash
docker-compose up nba-airflow
```

2. Acceder a Airflow UI: http://localhost:8080
   - Usuario: `admin`
   - Contraseña: `admin`

3. Activar DAG: `nba_ml_pipeline`

## 📈 Resultados y Métricas

### Modelos Supervisados
- **Accuracy**: > 65%
- **ROC-AUC**: > 0.70
- **F1-Score**: > 0.65

### Clustering
- **Silhouette Score**: > 0.3 (buena separación)
- **Davies-Bouldin Index**: < 1.5 (clusters compactos)
- **K óptimo**: Determinado automáticamente con método del codo

### Integración
- **Mejora con clustering features**: Medición de impacto en métricas supervisadas
- **Análisis comparativo**: Modelos con y sin features de clustering

## 🔧 Configuración Avanzada

### Parámetros

Los parámetros están organizados en `conf/base/`:
- `parameters.yml`: Configuración global
- `parameters_data_processing.yml`: Procesamiento de datos
- `parameters_data_science.yml`: Clasificación
- `parameters_regression.yml`: Regresión
- `parameters_unsupervised.yml`: Aprendizaje no supervisado
- `parameters_reporting.yml`: Reportes

### Personalización

Modifica parámetros en `conf/local/` para:
- Ajustar hiperparámetros de clustering
- Cambiar número de clusters
- Modificar técnicas de reducción dimensional
- Configurar detección de anomalías

## 📚 Documentación

### Documentos Principales
- `docs/architecture.md`: Arquitectura completa del proyecto
- `docs/unsupervised_analysis.md`: Análisis detallado de técnicas no supervisadas

### Notebooks
- `notebooks/05_unsupervised_learning.ipynb`: Análisis de aprendizaje no supervisado
- `notebooks/06_final_analysis.ipynb`: Análisis final integrado

## 🐳 Docker

### Servicios Disponibles

1. **nba-ml**: Pipeline principal
2. **nba-jupyter**: Jupyter notebooks (puerto 8888)
3. **nba-airflow**: Orquestación Airflow (puerto 8080)

### Volúmenes
- `./data`: Datos y resultados
- `./metrics`: Métricas de experimentos
- `./plots`: Visualizaciones
- `./logs`: Logs de ejecución

## 🔄 Orquestación con Airflow

### DAG Principal: `nba_ml_pipeline`

**Flujo de Ejecución:**
```
check_data_availability
    ↓
data_processing_pipeline
    ↓
data_science_pipeline
    ↓
unsupervised_learning_pipeline
    ↓
reporting_pipeline
    ↓
consolidate_results
    ↓
notify_completion
```

### Características
- **Manejo de Errores**: Retry automático con backoff
- **Logs**: Integración completa con Airflow logs
- **XComs**: Compartir datos entre tareas
- **Parametrización**: Variables de entorno configurables

## 📦 Versionado con DVC

### Artefactos Versionados
- Modelos entrenados (clustering, clasificación, regresión)
- Datos procesados
- Métricas de experimentos
- Visualizaciones

### Comandos Útiles
```bash
# Agregar archivos a DVC
dvc add data/06_models/

# Versionar métricas
dvc metrics show

# Comparar experimentos
dvc metrics diff
```

## 🧪 Testing

```bash
# Todos los tests
pytest

# Tests específicos
pytest tests/pipelines/unsupervised_learning/

# Con cobertura
pytest --cov=src/nba
```

## 🤝 Contribución

1. Fork el proyecto
2. Crea una rama (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

## 📄 Licencia

Este proyecto está bajo la Licencia MIT.

## 🙏 Agradecimientos

- [Kedro](https://kedro.org) - Framework de MLOps
- [Apache Airflow](https://airflow.apache.org/) - Orquestación
- [DVC](https://dvc.org/) - Versionado de datos
- [Scikit-learn](https://scikit-learn.org/) - Machine Learning
- [NBA](https://www.nba.com) - Datos históricos

---

**Desarrollado con ❤️ para análisis avanzado de datos NBA**
