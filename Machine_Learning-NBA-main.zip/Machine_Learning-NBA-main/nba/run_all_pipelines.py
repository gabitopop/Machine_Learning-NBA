"""
Script para ejecutar todos los pipelines de unsupervised learning individualmente.
Este script prueba la ejecución real de cada sub-pipeline.
"""

import sys
import subprocess
from pathlib import Path
import time

project_root = Path(__file__).parent


def run_pipeline(pipeline_name, description):
    """Ejecuta un pipeline de Kedro y muestra los resultados."""
    print("\n" + "=" * 70)
    print(f"EJECUTANDO: {description}")
    print(f"Pipeline: {pipeline_name}")
    print("=" * 70)
    
    try:
        start_time = time.time()
        
        # Ejecutar comando Kedro
        result = subprocess.run(
            ["kedro", "run", "--pipeline", pipeline_name],
            cwd=project_root,
            capture_output=True,
            text=True,
            timeout=600  # 10 minutos máximo por pipeline
        )
        
        elapsed_time = time.time() - start_time
        
        if result.returncode == 0:
            print(f"\nOK Pipeline '{pipeline_name}' completado exitosamente")
            print(f"Tiempo de ejecucion: {elapsed_time:.2f} segundos")
            
            # Mostrar últimas líneas de salida
            output_lines = result.stdout.split('\n')
            print("\nUltimas lineas de salida:")
            for line in output_lines[-10:]:
                if line.strip():
                    print(f"  {line}")
            
            return True
        else:
            print(f"\nERROR Pipeline '{pipeline_name}' fallo")
            print(f"Codigo de salida: {result.returncode}")
            print(f"Tiempo de ejecucion: {elapsed_time:.2f} segundos")
            
            if result.stderr:
                print("\nErrores:")
                error_lines = result.stderr.split('\n')[-20:]
                for line in error_lines:
                    if line.strip():
                        print(f"  {line}")
            
            if result.stdout:
                print("\nSalida (ultimas lineas):")
                output_lines = result.stdout.split('\n')[-10:]
                for line in output_lines:
                    if line.strip():
                        print(f"  {line}")
            
            return False
            
    except subprocess.TimeoutExpired:
        print(f"\nTIMEOUT Pipeline '{pipeline_name}' tardo mas de 10 minutos")
        return False
    except FileNotFoundError:
        print(f"\nERROR Kedro no encontrado en PATH")
        print("Asegurate de tener Kedro instalado y en el PATH")
        return False
    except Exception as e:
        print(f"\nERROR Excepcion al ejecutar pipeline: {e}")
        import traceback
        traceback.print_exc()
        return False


def check_prerequisites():
    """Verifica que los prerequisitos esten cumplidos."""
    print("=" * 70)
    print("VERIFICACION DE PREREQUISITOS")
    print("=" * 70)
    
    checks = []
    
    # Verificar que Kedro esta instalado
    try:
        result = subprocess.run(
            ["kedro", "--version"],
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode == 0:
            print(f"OK Kedro instalado: {result.stdout.strip()}")
            checks.append(True)
        else:
            print("ERROR Kedro no funciona correctamente")
            checks.append(False)
    except FileNotFoundError:
        print("ERROR Kedro no encontrado en PATH")
        checks.append(False)
    except Exception as e:
        print(f"ERROR Al verificar Kedro: {e}")
        checks.append(False)
    
    # Verificar que existen los datos
    data_file = project_root / "data" / "01_raw" / "game.csv"
    if data_file.exists():
        print(f"OK Archivo de datos encontrado: {data_file}")
        checks.append(True)
    else:
        print(f"ADVERTENCIA Archivo de datos no encontrado: {data_file}")
        print("  Los pipelines pueden fallar si no hay datos")
        checks.append(False)
    
    # Verificar estructura de directorios
    required_dirs = [
        "src/nba/pipelines/unsupervised_learning/clustering",
        "src/nba/pipelines/unsupervised_learning/dimensionality_reduction",
        "src/nba/pipelines/unsupervised_learning/anomaly_detection",
        "src/nba/pipelines/unsupervised_learning/association_rules",
    ]
    
    print("\nVerificando estructura de directorios:")
    for dir_path in required_dirs:
        full_path = project_root / dir_path
        if full_path.exists():
            print(f"  OK {dir_path}")
            checks.append(True)
        else:
            print(f"  ERROR {dir_path} no existe")
            checks.append(False)
    
    return all(checks)


def main():
    """Ejecuta todos los pipelines de unsupervised learning."""
    print("\n" + "=" * 70)
    print("EJECUCION DE TODOS LOS PIPELINES DE UNSUPERVISED LEARNING")
    print("=" * 70)
    print("\nEste script ejecutara cada sub-pipeline individualmente")
    print("para verificar que funcionan correctamente.\n")
    
    # Verificar prerequisitos
    if not check_prerequisites():
        print("\n" + "=" * 70)
        print("ADVERTENCIA: Algunos prerequisitos no se cumplen")
        print("Continuando de todas formas...")
        print("=" * 70)
    
    # Pipelines a ejecutar
    pipelines_to_run = [
        ("unsupervised_learning.clustering", "Clustering (K-Means, DBSCAN, Hierarchical, GMM, OPTICS)"),
        ("unsupervised_learning.dimensionality_reduction", "Reduccion de Dimensionalidad (PCA, t-SNE, UMAP, SVD)"),
        ("unsupervised_learning.anomaly_detection", "Deteccion de Anomalias (Isolation Forest, LOF, One-Class SVM, Autoencoder)"),
        ("unsupervised_learning.association_rules", "Reglas de Asociacion (Apriori, FP-Growth)"),
    ]
    
    results = []
    total_start_time = time.time()
    
    for pipeline_name, description in pipelines_to_run:
        success = run_pipeline(pipeline_name, description)
        results.append((pipeline_name, description, success))
        
        # Pausa entre pipelines
        if success:
            print("\nEsperando 2 segundos antes del siguiente pipeline...")
            time.sleep(2)
    
    total_elapsed = time.time() - total_start_time
    
    # Resumen final
    print("\n" + "=" * 70)
    print("RESUMEN DE EJECUCION")
    print("=" * 70)
    
    passed = sum(1 for _, _, success in results if success)
    total = len(results)
    
    print(f"\nTiempo total de ejecucion: {total_elapsed:.2f} segundos ({total_elapsed/60:.2f} minutos)")
    print(f"\nResultados por pipeline:")
    
    for pipeline_name, description, success in results:
        status = "OK" if success else "ERROR"
        print(f"  {status} - {pipeline_name}")
        print(f"         {description}")
    
    print(f"\n{'=' * 70}")
    print(f"Total: {passed}/{total} pipelines ejecutados exitosamente")
    print(f"{'=' * 70}\n")
    
    if passed == total:
        print("TODOS LOS PIPELINES SE EJECUTARON EXITOSAMENTE")
        print("\nLos tasks separados estan funcionando correctamente.")
        print("Puedes ejecutar cada uno individualmente desde:")
        print("  - Terminal: kedro run --pipeline <nombre>")
        print("  - Airflow UI: Trigger individual de cada task")
        return 0
    else:
        print("ALGUNOS PIPELINES FALLARON")
        print("Revisa los errores arriba para mas detalles.")
        print("\nNOTA: Si los datos no estan disponibles, los pipelines fallaran.")
        print("Asegurate de tener los datos en data/01_raw/ antes de ejecutar.")
        return 1


if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)
