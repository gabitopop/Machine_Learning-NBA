"""Project pipelines para el proyecto NBA."""

from kedro.framework.project import find_pipelines
from kedro.pipeline import Pipeline


def register_pipelines() -> dict[str, Pipeline]:
    """Registra los pipelines del proyecto NBA.

    Este proyecto incluye varios pipelines:
    1. data_processing: Limpieza y preparación de datos NBA
    2. data_science: Entrenamiento y evaluación de modelos de clasificación
    3. regression: Entrenamiento y evaluación de modelos de regresión
    4. reporting: Generación de visualizaciones y reportes (clasificación)
    5. regression_reporting: Generación de visualizaciones y reportes (regresión)
    6. unsupervised_learning: Aprendizaje no supervisado (clustering, reducción dimensional, anomalías, reglas)

    Returns:
        Un mapeo de nombres de pipelines a objetos ``Pipeline``.
    """
    pipelines = find_pipelines()
    
    # Pipeline completo (todos los pipelines combinados)
    pipelines["__default__"] = sum(pipelines.values())
    
    # Pipeline solo de procesamiento de datos
    pipelines["data_processing"] = pipelines["data_processing"]
    
    # Pipeline solo de ciencia de datos (clasificación)
    pipelines["data_science"] = pipelines["data_science"]
    
    # Pipeline solo de reportes (clasificación)
    pipelines["reporting"] = pipelines["reporting"]
    
    # Pipeline de ML completo (procesamiento + ciencia de datos)
    pipelines["ml_pipeline"] = pipelines["data_processing"] + pipelines["data_science"]
    
    # Pipelines de regresión (opcionales, solo si existen)
    if "regression" in pipelines:
        pipelines["regression"] = pipelines["regression"]
        
        # Pipeline de regresión completo (procesamiento + regresión)
        pipelines["regression_pipeline"] = pipelines["data_processing"] + pipelines["regression"]
        
        if "regression_reporting" in pipelines:
            pipelines["regression_reporting"] = pipelines["regression_reporting"]
            
            # Pipeline completo de regresión con reportes
            pipelines["full_regression_pipeline"] = (
                pipelines["data_processing"] + 
                pipelines["regression"] + 
                pipelines["regression_reporting"]
            )
    
    # Pipeline completo con reportes (clasificación)
    pipelines["full_pipeline"] = (
        pipelines["data_processing"] + 
        pipelines["data_science"] + 
        pipelines["reporting"]
    )
    
    # Pipeline de aprendizaje no supervisado (opcional, solo si existe)
    if "unsupervised_learning" in pipelines:
        pipelines["unsupervised_learning"] = pipelines["unsupervised_learning"]
    
    # Registrar sub-pipelines de unsupervised learning para ejecución individual
    # Esto permite ejecutar: kedro run --pipeline unsupervised_learning.clustering
    from nba.pipelines.unsupervised_learning.clustering.pipeline import create_pipeline as create_clustering_pipeline
    from nba.pipelines.unsupervised_learning.dimensionality_reduction.pipeline import create_pipeline as create_dimensionality_reduction_pipeline
    from nba.pipelines.unsupervised_learning.anomaly_detection.pipeline import create_pipeline as create_anomaly_detection_pipeline
    from nba.pipelines.unsupervised_learning.association_rules.pipeline import create_pipeline as create_association_rules_pipeline
    from nba.pipelines.unsupervised_learning.integration.pipeline import create_pipeline as create_integration_pipeline
    
    pipelines["unsupervised_learning.clustering"] = create_clustering_pipeline()
    pipelines["unsupervised_learning.dimensionality_reduction"] = create_dimensionality_reduction_pipeline()
    pipelines["unsupervised_learning.anomaly_detection"] = create_anomaly_detection_pipeline()
    pipelines["unsupervised_learning.association_rules"] = create_association_rules_pipeline()
    pipelines["unsupervised_learning.integration"] = create_integration_pipeline()
    
    # Pipeline completo con aprendizaje no supervisado (solo si existe)
    if "unsupervised_learning" in pipelines:
        pipelines["full_unsupervised_pipeline"] = (
            pipelines["data_processing"] + 
            pipelines["unsupervised_learning"]
        )
        
        # Pipeline completo ML + Unsupervised
        pipelines["complete_ml_pipeline"] = (
            pipelines["data_processing"] + 
            pipelines["data_science"] + 
            pipelines["unsupervised_learning"] + 
            pipelines["reporting"]
        )
    
    return pipelines
