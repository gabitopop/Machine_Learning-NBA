"""Nodos para el pipeline de detección de anomalías del proyecto NBA."""

import logging
import pandas as pd
import numpy as np
import pickle
import json
from typing import Dict, Tuple, Any
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from sklearn.svm import OneClassSVM
from sklearn.preprocessing import StandardScaler
try:
    from pyod.models.auto_encoder import AutoEncoder
    AUTOENCODER_AVAILABLE = True
except ImportError:
    AUTOENCODER_AVAILABLE = False
    AutoEncoder = None
import warnings

warnings.filterwarnings("ignore")
logger = logging.getLogger(__name__)


def prepare_data_for_anomaly_detection(
    data: pd.DataFrame, parameters: dict
) -> Tuple[pd.DataFrame, StandardScaler]:
    """Prepara los datos para detección de anomalías.

    Args:
        data: Datos con características.
        parameters: Parámetros de detección de anomalías.

    Returns:
        Datos preparados y scaler utilizado.
    """
    logger.info("Preparando datos para detección de anomalías...")

    # Obtener columnas de características
    target_column = parameters.get("target", "home_win")
    feature_columns = [col for col in data.columns if col != target_column]

    # Seleccionar solo características numéricas
    numeric_features = data[feature_columns].select_dtypes(include=[np.number]).columns.tolist()

    # Eliminar columnas con varianza cero o nulas
    X = data[numeric_features].copy()
    X = X.dropna()
    X = X.loc[:, X.var() != 0]

    logger.info(f"Datos preparados: {X.shape[0]} muestras, {X.shape[1]} características")

    # Escalar datos
    scaler = StandardScaler()
    X_scaled = pd.DataFrame(
        scaler.fit_transform(X), columns=X.columns, index=X.index
    )

    return X_scaled, scaler


def train_isolation_forest(
    data: pd.DataFrame, parameters: dict
) -> Tuple[IsolationForest, pd.Series, Dict[str, Any]]:
    """Entrena modelo Isolation Forest.

    Args:
        data: Datos escalados.
        parameters: Parámetros de Isolation Forest.

    Returns:
        Modelo Isolation Forest, predicciones y métricas.
    """
    logger.info("Entrenando modelo Isolation Forest...")

    if_params = parameters.get("isolation_forest", {})
    contamination = if_params.get("contamination", 0.1)
    random_state = parameters.get("random_state", 42)

    isolation_forest = IsolationForest(
        contamination=contamination, random_state=random_state, n_estimators=100
    )
    predictions = pd.Series(
        isolation_forest.fit_predict(data), index=data.index
    )
    # Convertir -1 (anomalía) a 1, 1 (normal) a 0
    anomaly_labels = (predictions == -1).astype(int)

    scores = isolation_forest.score_samples(data)

    metrics = {
        "n_anomalies": int(anomaly_labels.sum()),
        "n_normal": int((anomaly_labels == 0).sum()),
        "contamination": contamination,
        "anomaly_rate": float(anomaly_labels.mean()),
        "mean_anomaly_score": float(scores[anomaly_labels == 1].mean()) if anomaly_labels.sum() > 0 else 0,
    }

    logger.info(f"Isolation Forest completado: {metrics['n_anomalies']} anomalías detectadas")

    return isolation_forest, anomaly_labels, metrics


def train_lof(
    data: pd.DataFrame, parameters: dict
) -> Tuple[LocalOutlierFactor, pd.Series, Dict[str, Any]]:
    """Entrena modelo Local Outlier Factor (LOF).

    Args:
        data: Datos escalados.
        parameters: Parámetros de LOF.

    Returns:
        Modelo LOF, predicciones y métricas.
    """
    logger.info("Entrenando modelo Local Outlier Factor...")

    lof_params = parameters.get("lof", {})
    n_neighbors = lof_params.get("n_neighbors", 20)
    contamination = lof_params.get("contamination", 0.1)

    lof = LocalOutlierFactor(n_neighbors=n_neighbors, contamination=contamination)
    predictions = pd.Series(lof.fit_predict(data), index=data.index)
    # Convertir -1 (anomalía) a 1, 1 (normal) a 0
    anomaly_labels = (predictions == -1).astype(int)

    scores = -lof.negative_outlier_factor_  # Mayor score = más anómalo

    metrics = {
        "n_anomalies": int(anomaly_labels.sum()),
        "n_normal": int((anomaly_labels == 0).sum()),
        "n_neighbors": n_neighbors,
        "contamination": contamination,
        "anomaly_rate": float(anomaly_labels.mean()),
        "mean_anomaly_score": float(scores[anomaly_labels == 1].mean()) if anomaly_labels.sum() > 0 else 0,
    }

    logger.info(f"LOF completado: {metrics['n_anomalies']} anomalías detectadas")

    return lof, anomaly_labels, metrics


def train_one_class_svm(
    data: pd.DataFrame, parameters: dict
) -> Tuple[OneClassSVM, pd.Series, Dict[str, Any]]:
    """Entrena modelo One-Class SVM.

    Args:
        data: Datos escalados.
        parameters: Parámetros de One-Class SVM.

    Returns:
        Modelo One-Class SVM, predicciones y métricas.
    """
    logger.info("Entrenando modelo One-Class SVM...")

    svm_params = parameters.get("one_class_svm", {})
    nu = svm_params.get("nu", 0.1)
    kernel = svm_params.get("kernel", "rbf")
    gamma = svm_params.get("gamma", "scale")
    random_state = parameters.get("random_state", 42)

    one_class_svm = OneClassSVM(
        nu=nu, kernel=kernel, gamma=gamma, random_state=random_state
    )
    predictions = pd.Series(
        one_class_svm.fit_predict(data), index=data.index
    )
    # Convertir -1 (anomalía) a 1, 1 (normal) a 0
    anomaly_labels = (predictions == -1).astype(int)

    scores = one_class_svm.score_samples(data)

    metrics = {
        "n_anomalies": int(anomaly_labels.sum()),
        "n_normal": int((anomaly_labels == 0).sum()),
        "nu": nu,
        "kernel": kernel,
        "anomaly_rate": float(anomaly_labels.mean()),
        "mean_anomaly_score": float(scores[anomaly_labels == 1].mean()) if anomaly_labels.sum() > 0 else 0,
    }

    logger.info(f"One-Class SVM completado: {metrics['n_anomalies']} anomalías detectadas")

    return one_class_svm, anomaly_labels, metrics


def train_autoencoder(
    data: pd.DataFrame, parameters: dict
) -> Tuple[Any, pd.Series, Dict[str, Any]]:
    """Entrena modelo Autoencoder para detección de anomalías.

    Args:
        data: Datos escalados.
        parameters: Parámetros de Autoencoder.

    Returns:
        Modelo Autoencoder, predicciones y métricas.
    """
    logger.info("Entrenando modelo Autoencoder...")

    if not AUTOENCODER_AVAILABLE:
        logger.warning("AutoEncoder no disponible (torch no instalado). Saltando entrenamiento.")
        predictions = pd.Series(np.zeros(len(data)), index=data.index)
        metrics = {
            "n_anomalies": 0,
            "n_normal": len(data),
            "contamination": 0.1,
            "anomaly_rate": 0.0,
            "mean_anomaly_score": 0.0,
            "error": "AutoEncoder no disponible - torch no instalado",
        }
        return None, predictions, metrics

    ae_params = parameters.get("autoencoder", {})
    contamination = ae_params.get("contamination", 0.1)
    random_state = parameters.get("random_state", 42)
    epochs = ae_params.get("epochs", 50)
    batch_size = ae_params.get("batch_size", 32)

    try:
        autoencoder = AutoEncoder(
            contamination=contamination,
            random_state=random_state,
            epochs=epochs,
            batch_size=batch_size,
            verbose=0,
        )
        autoencoder.fit(data)
        predictions = pd.Series(
            autoencoder.predict(data), index=data.index
        )
        scores = autoencoder.decision_function(data)

        metrics = {
            "n_anomalies": int(predictions.sum()),
            "n_normal": int((predictions == 0).sum()),
            "contamination": contamination,
            "anomaly_rate": float(predictions.mean()),
            "mean_anomaly_score": float(scores[predictions == 1].mean()) if predictions.sum() > 0 else 0,
        }

        logger.info(f"Autoencoder completado: {metrics['n_anomalies']} anomalías detectadas")
    except Exception as e:
        logger.warning(f"Error entrenando Autoencoder: {e}. Usando valores por defecto.")
        predictions = pd.Series(np.zeros(len(data)), index=data.index)
        scores = np.zeros(len(data))
        metrics = {
            "n_anomalies": 0,
            "n_normal": len(data),
            "contamination": contamination,
            "anomaly_rate": 0.0,
            "mean_anomaly_score": 0.0,
            "error": str(e),
        }
        autoencoder = None

    return autoencoder, predictions, metrics


def compare_anomaly_detection_models(
    if_metrics: Dict[str, Any],
    lof_metrics: Dict[str, Any],
    svm_metrics: Dict[str, Any],
    ae_metrics: Dict[str, Any],
) -> pd.DataFrame:
    """Compara todos los modelos de detección de anomalías.

    Args:
        if_metrics: Métricas de Isolation Forest.
        lof_metrics: Métricas de LOF.
        svm_metrics: Métricas de One-Class SVM.
        ae_metrics: Métricas de Autoencoder.

    Returns:
        DataFrame con comparación de modelos.
    """
    logger.info("Comparando modelos de detección de anomalías...")

    comparison_data = {
        "Isolation Forest": {
            "N Anomalías": if_metrics.get("n_anomalies", 0),
            "Tasa de Anomalías": if_metrics.get("anomaly_rate", 0),
            "Score Promedio": if_metrics.get("mean_anomaly_score", 0),
        },
        "LOF": {
            "N Anomalías": lof_metrics.get("n_anomalies", 0),
            "Tasa de Anomalías": lof_metrics.get("anomaly_rate", 0),
            "Score Promedio": lof_metrics.get("mean_anomaly_score", 0),
        },
        "One-Class SVM": {
            "N Anomalías": svm_metrics.get("n_anomalies", 0),
            "Tasa de Anomalías": svm_metrics.get("anomaly_rate", 0),
            "Score Promedio": svm_metrics.get("mean_anomaly_score", 0),
        },
        "Autoencoder": {
            "N Anomalías": ae_metrics.get("n_anomalies", 0),
            "Tasa de Anomalías": ae_metrics.get("anomaly_rate", 0),
            "Score Promedio": ae_metrics.get("mean_anomaly_score", 0),
        },
    }

    comparison_df = pd.DataFrame(comparison_data).T
    logger.info("\nComparación de modelos de detección de anomalías:")
    logger.info(f"\n{comparison_df}")

    return comparison_df


def create_anomaly_detection_visualizations(
    data: pd.DataFrame,
    if_labels: pd.Series,
    lof_labels: pd.Series,
    svm_labels: pd.Series,
    ae_labels: pd.Series,
    parameters: dict,
) -> Dict[str, str]:
    """Crea visualizaciones para detección de anomalías.

    Args:
        data: Datos escalados.
        if_labels: Etiquetas de Isolation Forest.
        lof_labels: Etiquetas de LOF.
        svm_labels: Etiquetas de One-Class SVM.
        ae_labels: Etiquetas de Autoencoder.
        parameters: Parámetros de detección de anomalías.

    Returns:
        Diccionario con rutas de visualizaciones guardadas.
    """
    logger.info("Creando visualizaciones de detección de anomalías...")

    # Reducir dimensionalidad para visualización 2D usando PCA
    from sklearn.decomposition import PCA

    pca = PCA(n_components=2)
    data_2d = pca.fit_transform(data)

    visualizations = {}

    # Visualización comparativa de todos los modelos
    fig, axes = plt.subplots(2, 2, figsize=(16, 16))
    axes = axes.flatten()

    algorithms = [
        ("Isolation Forest", if_labels),
        ("LOF", lof_labels),
        ("One-Class SVM", svm_labels),
        ("Autoencoder", ae_labels),
    ]

    for idx, (name, labels) in enumerate(algorithms):
        ax = axes[idx]
        normal_mask = labels == 0
        anomaly_mask = labels == 1

        ax.scatter(
            data_2d[normal_mask, 0],
            data_2d[normal_mask, 1],
            c="blue",
            alpha=0.5,
            s=20,
            label="Normal",
        )
        ax.scatter(
            data_2d[anomaly_mask, 0],
            data_2d[anomaly_mask, 1],
            c="red",
            alpha=0.8,
            s=30,
            marker="x",
            label="Anomalía",
        )
        ax.set_xlabel("Primera Componente Principal")
        ax.set_ylabel("Segunda Componente Principal")
        ax.set_title(f"{name} - Detección de Anomalías")
        ax.legend()
        ax.grid(True, alpha=0.3)

    plt.tight_layout()
    anomaly_comparison_path = "data/08_reporting/anomaly_detection_comparison.png"
    plt.savefig(anomaly_comparison_path, dpi=300, bbox_inches="tight")
    plt.close()
    visualizations["anomaly_comparison"] = anomaly_comparison_path

    logger.info("Visualizaciones de detección de anomalías creadas exitosamente")

    return visualizations

