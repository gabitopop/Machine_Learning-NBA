"""Pipeline de detección de anomalías para el proyecto NBA."""

