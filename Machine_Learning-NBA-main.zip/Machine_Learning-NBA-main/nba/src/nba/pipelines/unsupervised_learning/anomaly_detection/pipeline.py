"""Pipeline de detección de anomalías para el proyecto NBA."""

from kedro.pipeline import Node, Pipeline

from .nodes import (
    prepare_data_for_anomaly_detection,
    train_isolation_forest,
    train_lof,
    train_one_class_svm,
    train_autoencoder,
    compare_anomaly_detection_models,
    create_anomaly_detection_visualizations,
)


def create_pipeline(**kwargs) -> Pipeline:
    """Crea el pipeline de detección de anomalías para el proyecto NBA.

    Este pipeline implementa múltiples algoritmos de detección de anomalías:
    - Isolation Forest
    - Local Outlier Factor (LOF)
    - One-Class SVM
    - Autoencoders

    Returns:
        Pipeline de detección de anomalías NBA.
    """
    return Pipeline(
        [
            Node(
                func=prepare_data_for_anomaly_detection,
                inputs=["model_input_table", "params:unsupervised_learning.anomaly_detection"],
                outputs=["anomaly_data", "anomaly_scaler"],
                name="prepare_data_for_anomaly_detection_node",
                tags=["anomaly_detection", "data_preparation", "nba"],
            ),
            Node(
                func=train_isolation_forest,
                inputs=["anomaly_data", "params:unsupervised_learning.anomaly_detection"],
                outputs=["isolation_forest_model", "if_labels", "if_metrics"],
                name="train_isolation_forest_node",
                tags=["anomaly_detection", "isolation_forest", "nba"],
            ),
            Node(
                func=train_lof,
                inputs=["anomaly_data", "params:unsupervised_learning.anomaly_detection"],
                outputs=["lof_model", "lof_labels", "lof_metrics"],
                name="train_lof_node",
                tags=["anomaly_detection", "lof", "nba"],
            ),
            Node(
                func=train_one_class_svm,
                inputs=["anomaly_data", "params:unsupervised_learning.anomaly_detection"],
                outputs=["one_class_svm_model", "svm_labels", "svm_metrics"],
                name="train_one_class_svm_node",
                tags=["anomaly_detection", "one_class_svm", "nba"],
            ),
            Node(
                func=train_autoencoder,
                inputs=["anomaly_data", "params:unsupervised_learning.anomaly_detection"],
                outputs=["autoencoder_model", "ae_labels", "ae_metrics"],
                name="train_autoencoder_node",
                tags=["anomaly_detection", "autoencoder", "nba"],
            ),
            Node(
                func=compare_anomaly_detection_models,
                inputs=["if_metrics", "lof_metrics", "svm_metrics", "ae_metrics"],
                outputs="anomaly_comparison_table",
                name="compare_anomaly_detection_models_node",
                tags=["anomaly_detection", "comparison", "nba"],
            ),
            Node(
                func=create_anomaly_detection_visualizations,
                inputs=[
                    "anomaly_data",
                    "if_labels",
                    "lof_labels",
                    "svm_labels",
                    "ae_labels",
                    "params:unsupervised_learning.anomaly_detection",
                ],
                outputs="anomaly_visualizations",
                name="create_anomaly_detection_visualizations_node",
                tags=["anomaly_detection", "visualization", "nba"],
            ),
        ]
    )

