"""Pipeline principal de aprendizaje no supervisado para el proyecto NBA."""

from kedro.pipeline import Pipeline

from .clustering.pipeline import create_pipeline as create_clustering_pipeline
from .dimensionality_reduction.pipeline import create_pipeline as create_dimensionality_reduction_pipeline
from .anomaly_detection.pipeline import create_pipeline as create_anomaly_detection_pipeline
from .association_rules.pipeline import create_pipeline as create_association_rules_pipeline
from .integration.pipeline import create_pipeline as create_integration_pipeline


def create_pipeline(**kwargs) -> Pipeline:
    """Crea el pipeline completo de aprendizaje no supervisado para el proyecto NBA.

    Este pipeline combina:
    - Clustering (K-Means, DBSCAN, Hierarchical, GMM, OPTICS)
    - Reducción de dimensionalidad (PCA, t-SNE, UMAP, SVD)
    - Detección de anomalías (Isolation Forest, LOF, One-Class SVM, Autoencoder)
    - Reglas de asociación (Apriori, FP-Growth)

    Returns:
        Pipeline completo de aprendizaje no supervisado NBA.
    """
    clustering_pipeline = create_clustering_pipeline()
    dimensionality_reduction_pipeline = create_dimensionality_reduction_pipeline()
    anomaly_detection_pipeline = create_anomaly_detection_pipeline()
    association_rules_pipeline = create_association_rules_pipeline()
    integration_pipeline = create_integration_pipeline()

    return (
        clustering_pipeline
        + dimensionality_reduction_pipeline
        + anomaly_detection_pipeline
        + association_rules_pipeline
        + integration_pipeline
    )

