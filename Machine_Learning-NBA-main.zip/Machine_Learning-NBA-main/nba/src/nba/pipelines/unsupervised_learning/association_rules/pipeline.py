"""Pipeline de reglas de asociación para el proyecto NBA."""

from kedro.pipeline import Node, Pipeline

from .nodes import (
    prepare_data_for_association_rules,
    mine_apriori_rules,
    mine_fpgrowth_rules,
    compare_association_rules_algorithms,
)


def create_pipeline(**kwargs) -> Pipeline:
    """Crea el pipeline de reglas de asociación para el proyecto NBA.

    Este pipeline implementa algoritmos de minería de reglas de asociación:
    - Apriori Algorithm
    - FP-Growth

    Returns:
        Pipeline de reglas de asociación NBA.
    """
    return Pipeline(
        [
            Node(
                func=prepare_data_for_association_rules,
                inputs=["model_input_table", "params:unsupervised_learning.association_rules"],
                outputs="association_data",
                name="prepare_data_for_association_rules_node",
                tags=["association_rules", "data_preparation", "nba"],
            ),
            Node(
                func=mine_apriori_rules,
                inputs=["association_data", "params:unsupervised_learning.association_rules"],
                outputs=["apriori_itemsets", "apriori_rules"],
                name="mine_apriori_rules_node",
                tags=["association_rules", "apriori", "nba"],
            ),
            Node(
                func=mine_fpgrowth_rules,
                inputs=["association_data", "params:unsupervised_learning.association_rules"],
                outputs=["fpgrowth_itemsets", "fpgrowth_rules"],
                name="mine_fpgrowth_rules_node",
                tags=["association_rules", "fpgrowth", "nba"],
            ),
            Node(
                func=compare_association_rules_algorithms,
                inputs=["apriori_rules", "fpgrowth_rules"],
                outputs="association_rules_comparison_table",
                name="compare_association_rules_algorithms_node",
                tags=["association_rules", "comparison", "nba"],
            ),
        ]
    )

