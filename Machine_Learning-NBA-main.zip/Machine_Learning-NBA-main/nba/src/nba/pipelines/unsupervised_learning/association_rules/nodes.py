"""Nodos para el pipeline de reglas de asociación del proyecto NBA."""

import logging
import pandas as pd
import numpy as np
from typing import Dict, Tuple, Any, List
from mlxtend.frequent_patterns import apriori, fpgrowth, association_rules
from mlxtend.preprocessing import TransactionEncoder
import warnings

warnings.filterwarnings("ignore")
logger = logging.getLogger(__name__)


def prepare_data_for_association_rules(
    data: pd.DataFrame, parameters: dict
) -> pd.DataFrame:
    """Prepara los datos para minería de reglas de asociación.

    Convierte datos numéricos en transacciones binarias basadas en cuantiles.

    Args:
        data: Datos con características.
        parameters: Parámetros de reglas de asociación.

    Returns:
        DataFrame binario para minería de reglas de asociación.
    """
    logger.info("Preparando datos para reglas de asociación...")

    # Obtener columnas de características
    target_column = parameters.get("target", "home_win")
    feature_columns = [col for col in data.columns if col != target_column]

    # Seleccionar solo características numéricas
    numeric_features = data[feature_columns].select_dtypes(include=[np.number]).columns.tolist()

    X = data[numeric_features].copy()
    X = X.dropna()

    # Convertir a binario usando cuantiles
    n_bins = parameters.get("n_bins", 3)
    binary_data = pd.DataFrame()

    for col in X.columns:
        # Crear bins y convertir a binario
        bins = pd.qcut(X[col], q=n_bins, duplicates="drop", labels=False)
        for bin_idx in range(bins.nunique()):
            binary_data[f"{col}_bin{bin_idx}"] = (bins == bin_idx).astype(int)

    logger.info(f"Datos binarios preparados: {binary_data.shape[0]} transacciones, {binary_data.shape[1]} items")

    return binary_data


def mine_apriori_rules(
    data: pd.DataFrame, parameters: dict
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Aplica algoritmo Apriori para encontrar itemsets frecuentes.

    Args:
        data: Datos binarios.
        parameters: Parámetros de Apriori.

    Returns:
        Itemsets frecuentes y reglas de asociación.
    """
    logger.info("Aplicando algoritmo Apriori...")

    apriori_params = parameters.get("apriori", {})
    min_support = apriori_params.get("min_support", 0.1)
    use_colnames = True

    try:
        # Encontrar itemsets frecuentes
        frequent_itemsets = apriori(
            data, min_support=min_support, use_colnames=use_colnames, verbose=0
        )

        if len(frequent_itemsets) > 0:
            # Generar reglas de asociación
            metric = apriori_params.get("metric", "confidence")
            min_threshold = apriori_params.get("min_threshold", 0.5)

            rules = association_rules(
                frequent_itemsets,
                metric=metric,
                min_threshold=min_threshold,
            )

            logger.info(f"Apriori completado: {len(frequent_itemsets)} itemsets, {len(rules)} reglas")
        else:
            logger.warning("Apriori: No se encontraron itemsets frecuentes")
            rules = pd.DataFrame()

    except Exception as e:
        logger.warning(f"Error en Apriori: {e}")
        frequent_itemsets = pd.DataFrame()
        rules = pd.DataFrame()

    return frequent_itemsets, rules


def mine_fpgrowth_rules(
    data: pd.DataFrame, parameters: dict
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Aplica algoritmo FP-Growth para encontrar itemsets frecuentes.

    Args:
        data: Datos binarios.
        parameters: Parámetros de FP-Growth.

    Returns:
        Itemsets frecuentes y reglas de asociación.
    """
    logger.info("Aplicando algoritmo FP-Growth...")

    fpgrowth_params = parameters.get("fpgrowth", {})
    min_support = fpgrowth_params.get("min_support", 0.1)
    use_colnames = True

    try:
        # Encontrar itemsets frecuentes
        frequent_itemsets = fpgrowth(
            data, min_support=min_support, use_colnames=use_colnames, verbose=0
        )

        if len(frequent_itemsets) > 0:
            # Generar reglas de asociación
            metric = fpgrowth_params.get("metric", "confidence")
            min_threshold = fpgrowth_params.get("min_threshold", 0.5)

            rules = association_rules(
                frequent_itemsets,
                metric=metric,
                min_threshold=min_threshold,
            )

            logger.info(f"FP-Growth completado: {len(frequent_itemsets)} itemsets, {len(rules)} reglas")
        else:
            logger.warning("FP-Growth: No se encontraron itemsets frecuentes")
            rules = pd.DataFrame()

    except Exception as e:
        logger.warning(f"Error en FP-Growth: {e}")
        frequent_itemsets = pd.DataFrame()
        rules = pd.DataFrame()

    return frequent_itemsets, rules


def compare_association_rules_algorithms(
    apriori_rules: pd.DataFrame,
    fpgrowth_rules: pd.DataFrame,
) -> pd.DataFrame:
    """Compara los algoritmos de reglas de asociación.

    Args:
        apriori_rules: Reglas de Apriori.
        fpgrowth_rules: Reglas de FP-Growth.

    Returns:
        DataFrame con comparación de algoritmos.
    """
    logger.info("Comparando algoritmos de reglas de asociación...")

    comparison_data = {
        "Apriori": {
            "N Reglas": len(apriori_rules) if not apriori_rules.empty else 0,
            "Support Promedio": float(apriori_rules["support"].mean()) if not apriori_rules.empty else 0,
            "Confidence Promedio": float(apriori_rules["confidence"].mean()) if not apriori_rules.empty else 0,
            "Lift Promedio": float(apriori_rules["lift"].mean()) if not apriori_rules.empty else 0,
        },
        "FP-Growth": {
            "N Reglas": len(fpgrowth_rules) if not fpgrowth_rules.empty else 0,
            "Support Promedio": float(fpgrowth_rules["support"].mean()) if not fpgrowth_rules.empty else 0,
            "Confidence Promedio": float(fpgrowth_rules["confidence"].mean()) if not fpgrowth_rules.empty else 0,
            "Lift Promedio": float(fpgrowth_rules["lift"].mean()) if not fpgrowth_rules.empty else 0,
        },
    }

    comparison_df = pd.DataFrame(comparison_data).T
    logger.info("\nComparación de algoritmos de reglas de asociación:")
    logger.info(f"\n{comparison_df}")

    return comparison_df

