"""Pipeline de reglas de asociación para el proyecto NBA."""

