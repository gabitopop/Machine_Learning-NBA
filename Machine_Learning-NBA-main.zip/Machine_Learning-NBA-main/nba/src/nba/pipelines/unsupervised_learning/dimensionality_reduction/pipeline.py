"""Pipeline de reducción de dimensionalidad para el proyecto NBA."""

from kedro.pipeline import Node, Pipeline

from .nodes import (
    prepare_data_for_dimensionality_reduction,
    apply_pca,
    apply_tsne,
    apply_umap,
    apply_svd,
    create_dimensionality_reduction_visualizations,
)


def create_pipeline(**kwargs) -> Pipeline:
    """Crea el pipeline de reducción de dimensionalidad para el proyecto NBA.

    Este pipeline implementa múltiples técnicas de reducción de dimensionalidad:
    - PCA (Análisis de Componentes Principales)
    - t-SNE (t-Distributed Stochastic Neighbor Embedding)
    - UMAP (Uniform Manifold Approximation and Projection)
    - Truncated SVD

    Returns:
        Pipeline de reducción de dimensionalidad NBA.
    """
    return Pipeline(
        [
            Node(
                func=prepare_data_for_dimensionality_reduction,
                inputs=["model_input_table", "params:unsupervised_learning.dimensionality_reduction"],
                outputs=["dr_data", "dr_scaler"],
                name="prepare_data_for_dimensionality_reduction_node",
                tags=["dimensionality_reduction", "data_preparation", "nba"],
            ),
            Node(
                func=apply_pca,
                inputs=["dr_data", "params:unsupervised_learning.dimensionality_reduction"],
                outputs=["pca_model", "pca_data", "pca_metrics"],
                name="apply_pca_node",
                tags=["dimensionality_reduction", "pca", "nba"],
            ),
            Node(
                func=apply_tsne,
                inputs=["dr_data", "params:unsupervised_learning.dimensionality_reduction"],
                outputs=["tsne_model", "tsne_data", "tsne_metrics"],
                name="apply_tsne_node",
                tags=["dimensionality_reduction", "tsne", "nba"],
            ),
            Node(
                func=apply_umap,
                inputs=["dr_data", "params:unsupervised_learning.dimensionality_reduction"],
                outputs=["umap_model", "umap_data", "umap_metrics"],
                name="apply_umap_node",
                tags=["dimensionality_reduction", "umap", "nba"],
            ),
            Node(
                func=apply_svd,
                inputs=["dr_data", "params:unsupervised_learning.dimensionality_reduction"],
                outputs=["svd_model", "svd_data", "svd_metrics"],
                name="apply_svd_node",
                tags=["dimensionality_reduction", "svd", "nba"],
            ),
            Node(
                func=create_dimensionality_reduction_visualizations,
                inputs=[
                    "dr_data",
                    "pca_model",
                    "pca_data",
                    "pca_metrics",
                    "tsne_data",
                    "umap_data",
                    "svd_data",
                    "params:unsupervised_learning.dimensionality_reduction",
                ],
                outputs="dr_visualizations",
                name="create_dimensionality_reduction_visualizations_node",
                tags=["dimensionality_reduction", "visualization", "nba"],
            ),
        ]
    )

