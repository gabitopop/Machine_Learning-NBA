"""Nodos para el pipeline de reducción de dimensionalidad del proyecto NBA."""

import logging
import pandas as pd
import numpy as np
import pickle
import json
from typing import Dict, Tuple, Any
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.decomposition import PCA, TruncatedSVD
from sklearn.preprocessing import StandardScaler
from sklearn.manifold import TSNE
import umap
import warnings

warnings.filterwarnings("ignore")
logger = logging.getLogger(__name__)


def prepare_data_for_dimensionality_reduction(
    data: pd.DataFrame, parameters: dict
) -> Tuple[pd.DataFrame, StandardScaler]:
    """Prepara los datos para reducción de dimensionalidad.

    Args:
        data: Datos con características.
        parameters: Parámetros de reducción de dimensionalidad.

    Returns:
        Datos preparados y scaler utilizado.
    """
    logger.info("Preparando datos para reducción de dimensionalidad...")

    # Obtener columnas de características
    target_column = parameters.get("target", "home_win")
    feature_columns = [col for col in data.columns if col != target_column]

    # Seleccionar solo características numéricas
    numeric_features = data[feature_columns].select_dtypes(include=[np.number]).columns.tolist()

    # Eliminar columnas con varianza cero o nulas
    X = data[numeric_features].copy()
    X = X.dropna()
    X = X.loc[:, X.var() != 0]

    logger.info(f"Datos preparados: {X.shape[0]} muestras, {X.shape[1]} características")

    # Escalar datos
    scaler = StandardScaler()
    X_scaled = pd.DataFrame(
        scaler.fit_transform(X), columns=X.columns, index=X.index
    )

    return X_scaled, scaler


def apply_pca(
    data: pd.DataFrame, parameters: dict
) -> Tuple[PCA, pd.DataFrame, Dict[str, Any]]:
    """Aplica Análisis de Componentes Principales (PCA).

    Args:
        data: Datos escalados.
        parameters: Parámetros de PCA.

    Returns:
        Modelo PCA, datos transformados y métricas.
    """
    logger.info("Aplicando PCA...")

    pca_params = parameters.get("pca", {})
    n_components = pca_params.get("n_components", None)
    random_state = parameters.get("random_state", 42)

    pca = PCA(n_components=n_components, random_state=random_state)
    data_transformed = pd.DataFrame(
        pca.fit_transform(data),
        index=data.index,
        columns=[f"PC{i+1}" for i in range(pca.n_components_)],
    )

    # Calcular métricas
    explained_variance = pca.explained_variance_ratio_
    cumulative_variance = np.cumsum(explained_variance)

    metrics = {
        "n_components": pca.n_components_,
        "explained_variance_ratio": explained_variance.tolist(),
        "cumulative_variance_ratio": cumulative_variance.tolist(),
        "total_variance_explained": float(cumulative_variance[-1]),
        "components": pca.components_.tolist(),
        "loadings": pca.components_.T.tolist(),
    }

    logger.info(f"PCA completado: {pca.n_components_} componentes")
    logger.info(f"  Varianza explicada total: {cumulative_variance[-1]:.4f}")
    logger.info(f"  Primeros 5 componentes explican: {cumulative_variance[4]:.4f}")

    return pca, data_transformed, metrics


def apply_tsne(
    data: pd.DataFrame, parameters: dict
) -> Tuple[TSNE, pd.DataFrame, Dict[str, Any]]:
    """Aplica t-SNE para visualización.

    Args:
        data: Datos escalados.
        parameters: Parámetros de t-SNE.

    Returns:
        Modelo t-SNE, datos transformados y métricas.
    """
    logger.info("Aplicando t-SNE...")

    tsne_params = parameters.get("tsne", {})
    n_components = tsne_params.get("n_components", 2)
    perplexity = tsne_params.get("perplexity", 30)
    random_state = parameters.get("random_state", 42)
    n_iter = tsne_params.get("n_iter", 1000)

    # Reducir dimensionalidad primero si hay muchas características
    if data.shape[1] > 50:
        logger.info("Reduciendo dimensionalidad previa con PCA para t-SNE...")
        pca_pre = PCA(n_components=50, random_state=random_state)
        data_reduced = pca_pre.fit_transform(data)
    else:
        data_reduced = data.values

    tsne = TSNE(
        n_components=n_components,
        perplexity=perplexity,
        random_state=random_state,
        n_iter=n_iter,
        verbose=0,
    )
    data_transformed = pd.DataFrame(
        tsne.fit_transform(data_reduced),
        index=data.index,
        columns=[f"t-SNE{i+1}" for i in range(n_components)],
    )

    metrics = {
        "n_components": n_components,
        "perplexity": perplexity,
        "n_iter": n_iter,
        "kl_divergence": float(tsne.kl_divergence_),
    }

    logger.info(f"t-SNE completado: {n_components} dimensiones")
    logger.info(f"  KL Divergence: {metrics['kl_divergence']:.4f}")

    return tsne, data_transformed, metrics


def apply_umap(
    data: pd.DataFrame, parameters: dict
) -> Tuple[umap.UMAP, pd.DataFrame, Dict[str, Any]]:
    """Aplica UMAP para reducción de dimensionalidad.

    Args:
        data: Datos escalados.
        parameters: Parámetros de UMAP.

    Returns:
        Modelo UMAP, datos transformados y métricas.
    """
    logger.info("Aplicando UMAP...")

    umap_params = parameters.get("umap", {})
    n_components = umap_params.get("n_components", 2)
    n_neighbors = umap_params.get("n_neighbors", 15)
    min_dist = umap_params.get("min_dist", 0.1)
    random_state = parameters.get("random_state", 42)

    umap_model = umap.UMAP(
        n_components=n_components,
        n_neighbors=n_neighbors,
        min_dist=min_dist,
        random_state=random_state,
    )
    data_transformed = pd.DataFrame(
        umap_model.fit_transform(data),
        index=data.index,
        columns=[f"UMAP{i+1}" for i in range(n_components)],
    )

    metrics = {
        "n_components": n_components,
        "n_neighbors": n_neighbors,
        "min_dist": min_dist,
    }

    logger.info(f"UMAP completado: {n_components} dimensiones")

    return umap_model, data_transformed, metrics


def apply_svd(
    data: pd.DataFrame, parameters: dict
) -> Tuple[TruncatedSVD, pd.DataFrame, Dict[str, Any]]:
    """Aplica SVD Truncado para datos sparse.

    Args:
        data: Datos escalados.
        parameters: Parámetros de SVD.

    Returns:
        Modelo SVD, datos transformados y métricas.
    """
    logger.info("Aplicando Truncated SVD...")

    svd_params = parameters.get("svd", {})
    n_components = svd_params.get("n_components", 10)
    random_state = parameters.get("random_state", 42)

    svd = TruncatedSVD(n_components=n_components, random_state=random_state)
    data_transformed = pd.DataFrame(
        svd.fit_transform(data),
        index=data.index,
        columns=[f"SVD{i+1}" for i in range(n_components)],
    )

    # Calcular varianza explicada
    explained_variance = svd.explained_variance_ratio_
    cumulative_variance = np.cumsum(explained_variance)

    metrics = {
        "n_components": n_components,
        "explained_variance_ratio": explained_variance.tolist(),
        "cumulative_variance_ratio": cumulative_variance.tolist(),
        "total_variance_explained": float(cumulative_variance[-1]),
        "singular_values": svd.singular_values_.tolist(),
    }

    logger.info(f"Truncated SVD completado: {n_components} componentes")
    logger.info(f"  Varianza explicada total: {cumulative_variance[-1]:.4f}")

    return svd, data_transformed, metrics


def create_dimensionality_reduction_visualizations(
    data: pd.DataFrame,
    pca_model: PCA,
    pca_data: pd.DataFrame,
    pca_metrics: Dict[str, Any],
    tsne_data: pd.DataFrame,
    umap_data: pd.DataFrame,
    svd_data: pd.DataFrame,
    parameters: dict,
) -> Dict[str, str]:
    """Crea visualizaciones para reducción de dimensionalidad.

    Args:
        data: Datos originales escalados.
        pca_model: Modelo PCA entrenado.
        pca_data: Datos transformados por PCA.
        pca_metrics: Métricas de PCA.
        tsne_data: Datos transformados por t-SNE.
        umap_data: Datos transformados por UMAP.
        svd_data: Datos transformados por SVD.
        parameters: Parámetros de reducción de dimensionalidad.

    Returns:
        Diccionario con rutas de visualizaciones guardadas.
    """
    logger.info("Creando visualizaciones de reducción de dimensionalidad...")

    visualizations = {}

    # 1. Varianza explicada por PCA
    fig, axes = plt.subplots(1, 2, figsize=(15, 5))

    explained_var = np.array(pca_metrics["explained_variance_ratio"])
    cumulative_var = np.array(pca_metrics["cumulative_variance_ratio"])

    # Varianza explicada individual
    axes[0].bar(range(1, min(21, len(explained_var) + 1)), explained_var[:20])
    axes[0].set_xlabel("Componente Principal")
    axes[0].set_ylabel("Varianza Explicada")
    axes[0].set_title("Varianza Explicada por Componente (PCA)")
    axes[0].grid(True, alpha=0.3)

    # Varianza acumulada
    axes[1].plot(range(1, len(cumulative_var) + 1), cumulative_var, marker="o")
    axes[1].axhline(y=0.95, color="r", linestyle="--", label="95% varianza")
    axes[1].set_xlabel("Número de Componentes")
    axes[1].set_ylabel("Varianza Acumulada")
    axes[1].set_title("Varianza Acumulada (PCA)")
    axes[1].legend()
    axes[1].grid(True, alpha=0.3)

    plt.tight_layout()
    pca_variance_path = "data/08_reporting/pca_variance_explained.png"
    plt.savefig(pca_variance_path, dpi=300, bbox_inches="tight")
    plt.close()
    visualizations["pca_variance"] = pca_variance_path

    # 2. Biplot PCA (primeros 2 componentes)
    fig, ax = plt.subplots(figsize=(12, 10))
    scatter = ax.scatter(
        pca_data["PC1"], pca_data["PC2"], alpha=0.6, s=20, c=range(len(pca_data))
    )
    ax.set_xlabel(f"PC1 ({pca_metrics['explained_variance_ratio'][0]:.2%} varianza)")
    ax.set_ylabel(f"PC2 ({pca_metrics['explained_variance_ratio'][1]:.2%} varianza)")
    ax.set_title("Biplot PCA - Primeros 2 Componentes")
    ax.grid(True, alpha=0.3)
    plt.colorbar(scatter, ax=ax, label="Índice de muestra")
    biplot_path = "data/08_reporting/pca_biplot.png"
    plt.savefig(biplot_path, dpi=300, bbox_inches="tight")
    plt.close()
    visualizations["pca_biplot"] = biplot_path

    # 3. Comparación de técnicas 2D
    fig, axes = plt.subplots(2, 2, figsize=(16, 16))
    axes = axes.flatten()

    # PCA 2D
    axes[0].scatter(pca_data["PC1"], pca_data["PC2"], alpha=0.6, s=20)
    axes[0].set_xlabel("PC1")
    axes[0].set_ylabel("PC2")
    axes[0].set_title("PCA (2D)")
    axes[0].grid(True, alpha=0.3)

    # t-SNE 2D
    axes[1].scatter(tsne_data["t-SNE1"], tsne_data["t-SNE2"], alpha=0.6, s=20)
    axes[1].set_xlabel("t-SNE1")
    axes[1].set_ylabel("t-SNE2")
    axes[1].set_title("t-SNE (2D)")
    axes[1].grid(True, alpha=0.3)

    # UMAP 2D
    axes[2].scatter(umap_data["UMAP1"], umap_data["UMAP2"], alpha=0.6, s=20)
    axes[2].set_xlabel("UMAP1")
    axes[2].set_ylabel("UMAP2")
    axes[2].set_title("UMAP (2D)")
    axes[2].grid(True, alpha=0.3)

    # SVD 2D
    axes[3].scatter(svd_data["SVD1"], svd_data["SVD2"], alpha=0.6, s=20)
    axes[3].set_xlabel("SVD1")
    axes[3].set_ylabel("SVD2")
    axes[3].set_title("Truncated SVD (2D)")
    axes[3].grid(True, alpha=0.3)

    plt.tight_layout()
    comparison_2d_path = "data/08_reporting/dimensionality_reduction_2d_comparison.png"
    plt.savefig(comparison_2d_path, dpi=300, bbox_inches="tight")
    plt.close()
    visualizations["comparison_2d"] = comparison_2d_path

    # 4. Loadings PCA (primeros 10 componentes)
    loadings = np.array(pca_metrics["loadings"])
    feature_names = data.columns[: min(20, len(data.columns))]

    fig, ax = plt.subplots(figsize=(12, 8))
    im = ax.imshow(loadings[:20, :10].T, aspect="auto", cmap="coolwarm")
    ax.set_xticks(range(len(feature_names)))
    ax.set_xticklabels(feature_names, rotation=45, ha="right")
    ax.set_yticks(range(10))
    ax.set_yticklabels([f"PC{i+1}" for i in range(10)])
    ax.set_xlabel("Características")
    ax.set_ylabel("Componentes Principales")
    ax.set_title("Loadings PCA - Primeros 10 Componentes")
    plt.colorbar(im, ax=ax, label="Loading")
    plt.tight_layout()
    loadings_path = "data/08_reporting/pca_loadings.png"
    plt.savefig(loadings_path, dpi=300, bbox_inches="tight")
    plt.close()
    visualizations["pca_loadings"] = loadings_path

    logger.info("Visualizaciones de reducción de dimensionalidad creadas exitosamente")

    return visualizations

