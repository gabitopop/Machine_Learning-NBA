"""Pipeline de reducción de dimensionalidad para el proyecto NBA."""

