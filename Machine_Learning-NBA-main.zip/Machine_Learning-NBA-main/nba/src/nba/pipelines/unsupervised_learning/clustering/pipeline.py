"""Pipeline de clustering para el proyecto NBA."""

from kedro.pipeline import Node, Pipeline

from .nodes import (
    prepare_data_for_clustering,
    find_optimal_k_elbow,
    train_kmeans,
    train_dbscan,
    train_hierarchical_clustering,
    train_gmm,
    train_optics,
    analyze_cluster_patterns,
    compare_clustering_models,
    create_clustering_visualizations,
)


def analyze_kmeans_patterns(data, labels, original_data, parameters):
    """Wrapper para analizar patrones de K-Means."""
    return analyze_cluster_patterns(data, labels, original_data, "K-Means", parameters)


def analyze_dbscan_patterns(data, labels, original_data, parameters):
    """Wrapper para analizar patrones de DBSCAN."""
    return analyze_cluster_patterns(data, labels, original_data, "DBSCAN", parameters)


def analyze_hierarchical_patterns(data, labels, original_data, parameters):
    """Wrapper para analizar patrones de Hierarchical Clustering."""
    return analyze_cluster_patterns(data, labels, original_data, "Hierarchical", parameters)


def create_pipeline(**kwargs) -> Pipeline:
    """Crea el pipeline de clustering para el proyecto NBA.

    Este pipeline implementa múltiples algoritmos de clustering:
    - K-Means
    - DBSCAN
    - Hierarchical Clustering
    - Gaussian Mixture Models
    - OPTICS

    Returns:
        Pipeline de clustering NBA.
    """
    return Pipeline(
        [
            Node(
                func=prepare_data_for_clustering,
                inputs=["model_input_table", "params:unsupervised_learning.clustering"],
                outputs=["clustering_data", "clustering_scaler"],
                name="prepare_data_for_clustering_node",
                tags=["clustering", "data_preparation", "nba"],
            ),
            Node(
                func=find_optimal_k_elbow,
                inputs=["clustering_data", "params:unsupervised_learning.clustering"],
                outputs="elbow_results",
                name="find_optimal_k_elbow_node",
                tags=["clustering", "elbow_method", "nba"],
            ),
            Node(
                func=train_kmeans,
                inputs=["clustering_data", "params:unsupervised_learning.clustering", "elbow_results"],
                outputs=["kmeans_model", "kmeans_labels", "kmeans_metrics"],
                name="train_kmeans_node",
                tags=["clustering", "kmeans", "nba"],
            ),
            Node(
                func=train_dbscan,
                inputs=["clustering_data", "params:unsupervised_learning.clustering"],
                outputs=["dbscan_model", "dbscan_labels", "dbscan_metrics"],
                name="train_dbscan_node",
                tags=["clustering", "dbscan", "nba"],
            ),
            Node(
                func=train_hierarchical_clustering,
                inputs=["clustering_data", "params:unsupervised_learning.clustering"],
                outputs=["hierarchical_model", "hierarchical_labels", "hierarchical_metrics", "linkage_matrix"],
                name="train_hierarchical_clustering_node",
                tags=["clustering", "hierarchical", "nba"],
            ),
            Node(
                func=train_gmm,
                inputs=["clustering_data", "params:unsupervised_learning.clustering"],
                outputs=["gmm_model", "gmm_labels", "gmm_metrics"],
                name="train_gmm_node",
                tags=["clustering", "gmm", "nba"],
            ),
            Node(
                func=train_optics,
                inputs=["clustering_data", "params:unsupervised_learning.clustering"],
                outputs=["optics_model", "optics_labels", "optics_metrics"],
                name="train_optics_node",
                tags=["clustering", "optics", "nba"],
            ),
            Node(
                func=analyze_kmeans_patterns,
                inputs=["clustering_data", "kmeans_labels", "model_input_table", "params:unsupervised_learning.clustering"],
                outputs="kmeans_patterns_analysis",
                name="analyze_kmeans_patterns_node",
                tags=["clustering", "pattern_analysis", "nba"],
            ),
            Node(
                func=analyze_dbscan_patterns,
                inputs=["clustering_data", "dbscan_labels", "model_input_table", "params:unsupervised_learning.clustering"],
                outputs="dbscan_patterns_analysis",
                name="analyze_dbscan_patterns_node",
                tags=["clustering", "pattern_analysis", "nba"],
            ),
            Node(
                func=analyze_hierarchical_patterns,
                inputs=["clustering_data", "hierarchical_labels", "model_input_table", "params:unsupervised_learning.clustering"],
                outputs="hierarchical_patterns_analysis",
                name="analyze_hierarchical_patterns_node",
                tags=["clustering", "pattern_analysis", "nba"],
            ),
            Node(
                func=compare_clustering_models,
                inputs=[
                    "kmeans_metrics",
                    "dbscan_metrics",
                    "hierarchical_metrics",
                    "gmm_metrics",
                    "optics_metrics",
                ],
                outputs="clustering_comparison_table",
                name="compare_clustering_models_node",
                tags=["clustering", "comparison", "nba"],
            ),
            Node(
                func=create_clustering_visualizations,
                inputs=[
                    "clustering_data",
                    "kmeans_labels",
                    "dbscan_labels",
                    "hierarchical_labels",
                    "gmm_labels",
                    "optics_labels",
                    "linkage_matrix",
                    "elbow_results",
                    "params:unsupervised_learning.clustering",
                ],
                outputs="clustering_visualizations",
                name="create_clustering_visualizations_node",
                tags=["clustering", "visualization", "nba"],
            ),
        ]
    )

