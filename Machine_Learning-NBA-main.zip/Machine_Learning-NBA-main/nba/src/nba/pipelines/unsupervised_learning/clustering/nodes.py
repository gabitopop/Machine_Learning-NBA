"""Nodos para el pipeline de clustering del proyecto NBA."""

import logging
import pandas as pd
import numpy as np
import pickle
import json
from typing import Dict, Tuple, Any
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.cluster.hierarchy import dendrogram, linkage
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    silhouette_score,
    davies_bouldin_score,
    calinski_harabasz_score,
)
from sklearn.cluster import OPTICS
import warnings

warnings.filterwarnings("ignore")
logger = logging.getLogger(__name__)


def prepare_data_for_clustering(
    data: pd.DataFrame, parameters: dict
) -> Tuple[pd.DataFrame, StandardScaler]:
    """Prepara los datos para clustering eliminando la variable objetivo y escalando.

    Args:
        data: Datos con características y variable objetivo.
        parameters: Parámetros de clustering.

    Returns:
        Datos preparados y scaler utilizado.
    """
    logger.info("Preparando datos para clustering...")

    # Obtener columnas de características
    target_column = parameters.get("target", "home_win")
    feature_columns = [col for col in data.columns if col != target_column]

    # Seleccionar solo características numéricas
    numeric_features = data[feature_columns].select_dtypes(include=[np.number]).columns.tolist()

    # Eliminar columnas con varianza cero o nulas
    X = data[numeric_features].copy()
    X = X.dropna()
    X = X.loc[:, X.var() != 0]

    logger.info(f"Datos preparados: {X.shape[0]} muestras, {X.shape[1]} características")

    # Escalar datos
    scaler = StandardScaler()
    X_scaled = pd.DataFrame(
        scaler.fit_transform(X), columns=X.columns, index=X.index
    )

    return X_scaled, scaler


def find_optimal_k_elbow(
    data: pd.DataFrame, parameters: dict
) -> Dict[str, Any]:
    """Encuentra el número óptimo de clusters usando el método del codo.

    Args:
        data: Datos escalados.
        parameters: Parámetros de clustering.

    Returns:
        Diccionario con k óptimo y métricas del método del codo.
    """
    logger.info("Calculando método del codo para K-Means...")

    k_range = parameters.get("k_range", range(2, 11))
    inertias = []
    k_values = list(k_range)

    for k in k_values:
        kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
        kmeans.fit(data)
        inertias.append(kmeans.inertia_)

    # Calcular diferencias para encontrar el codo
    diffs = np.diff(inertias)
    diff_diffs = np.diff(diffs)
    optimal_k = k_values[np.argmax(diff_diffs) + 1] if len(diff_diffs) > 0 else k_values[2]

    elbow_results = {
        "k_values": k_values,
        "inertias": inertias,
        "optimal_k": int(optimal_k),
    }

    logger.info(f"K óptimo encontrado: {optimal_k}")

    return elbow_results


def train_kmeans(
    data: pd.DataFrame, parameters: dict, elbow_results: Dict[str, Any]
) -> Tuple[KMeans, pd.Series, Dict[str, float]]:
    """Entrena modelo K-Means.

    Args:
        data: Datos escalados.
        parameters: Parámetros de clustering.
        elbow_results: Resultados del método del codo.

    Returns:
        Modelo K-Means entrenado, etiquetas de clusters y métricas.
    """
    logger.info("Entrenando modelo K-Means...")

    n_clusters = parameters.get("kmeans", {}).get("n_clusters", elbow_results["optimal_k"])
    random_state = parameters.get("random_state", 42)

    kmeans = KMeans(n_clusters=n_clusters, random_state=random_state, n_init=10)
    labels = pd.Series(kmeans.fit_predict(data), index=data.index)

    # Calcular métricas
    metrics = {
        "silhouette_score": silhouette_score(data, labels),
        "davies_bouldin_index": davies_bouldin_score(data, labels),
        "calinski_harabasz_index": calinski_harabasz_score(data, labels),
        "n_clusters": n_clusters,
        "inertia": kmeans.inertia_,
    }

    logger.info(f"K-Means completado: {n_clusters} clusters")
    logger.info(f"  Silhouette Score: {metrics['silhouette_score']:.4f}")
    logger.info(f"  Davies-Bouldin Index: {metrics['davies_bouldin_index']:.4f}")

    return kmeans, labels, metrics


def train_dbscan(
    data: pd.DataFrame, parameters: dict
) -> Tuple[DBSCAN, pd.Series, Dict[str, Any]]:
    """Entrena modelo DBSCAN.

    Args:
        data: Datos escalados.
        parameters: Parámetros de clustering.

    Returns:
        Modelo DBSCAN entrenado, etiquetas de clusters y métricas.
    """
    logger.info("Entrenando modelo DBSCAN...")

    dbscan_params = parameters.get("dbscan", {})
    eps = dbscan_params.get("eps", 0.5)
    min_samples = dbscan_params.get("min_samples", 5)

    dbscan = DBSCAN(eps=eps, min_samples=min_samples)
    labels = pd.Series(dbscan.fit_predict(data), index=data.index)

    n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
    n_noise = list(labels).count(-1)

    metrics = {
        "n_clusters": n_clusters,
        "n_noise_points": n_noise,
        "eps": eps,
        "min_samples": min_samples,
    }

    # Calcular métricas solo si hay más de 1 cluster
    if n_clusters > 1:
        # Filtrar puntos de ruido para métricas
        mask = labels != -1
        if mask.sum() > 1:
            metrics["silhouette_score"] = silhouette_score(
                data[mask], labels[mask]
            )
            metrics["davies_bouldin_index"] = davies_bouldin_score(
                data[mask], labels[mask]
            )
            metrics["calinski_harabasz_index"] = calinski_harabasz_score(
                data[mask], labels[mask]
            )
        else:
            metrics["silhouette_score"] = -1
            metrics["davies_bouldin_index"] = float("inf")
            metrics["calinski_harabasz_index"] = 0
    else:
        metrics["silhouette_score"] = -1
        metrics["davies_bouldin_index"] = float("inf")
        metrics["calinski_harabasz_index"] = 0

    logger.info(f"DBSCAN completado: {n_clusters} clusters, {n_noise} puntos de ruido")

    return dbscan, labels, metrics


def train_hierarchical_clustering(
    data: pd.DataFrame, parameters: dict
) -> Tuple[AgglomerativeClustering, pd.Series, Dict[str, Any], np.ndarray]:
    """Entrena modelo de clustering jerárquico.

    Args:
        data: Datos escalados.
        parameters: Parámetros de clustering.

    Returns:
        Modelo jerárquico, etiquetas, métricas y linkage matrix.
    """
    logger.info("Entrenando modelo de clustering jerárquico...")

    hierarchical_params = parameters.get("hierarchical", {})
    n_clusters = hierarchical_params.get("n_clusters", 3)
    linkage_method = hierarchical_params.get("linkage", "ward")

    # Crear linkage matrix para dendrograma
    linkage_matrix = linkage(data, method=linkage_method)

    hierarchical = AgglomerativeClustering(
        n_clusters=n_clusters, linkage=linkage_method
    )
    labels = pd.Series(hierarchical.fit_predict(data), index=data.index)

    # Calcular métricas
    metrics = {
        "silhouette_score": silhouette_score(data, labels),
        "davies_bouldin_index": davies_bouldin_score(data, labels),
        "calinski_harabasz_index": calinski_harabasz_score(data, labels),
        "n_clusters": n_clusters,
        "linkage": linkage_method,
    }

    logger.info(f"Clustering jerárquico completado: {n_clusters} clusters")
    logger.info(f"  Silhouette Score: {metrics['silhouette_score']:.4f}")

    return hierarchical, labels, metrics, linkage_matrix


def train_gmm(
    data: pd.DataFrame, parameters: dict
) -> Tuple[GaussianMixture, pd.Series, Dict[str, float]]:
    """Entrena modelo Gaussian Mixture Model.

    Args:
        data: Datos escalados.
        parameters: Parámetros de clustering.

    Returns:
        Modelo GMM, etiquetas y métricas.
    """
    logger.info("Entrenando modelo Gaussian Mixture Model...")

    gmm_params = parameters.get("gmm", {})
    n_components = gmm_params.get("n_components", 3)
    random_state = parameters.get("random_state", 42)

    gmm = GaussianMixture(
        n_components=n_components, random_state=random_state, n_init=10
    )
    labels = pd.Series(gmm.fit_predict(data), index=data.index)

    # Calcular métricas
    metrics = {
        "silhouette_score": silhouette_score(data, labels),
        "davies_bouldin_index": davies_bouldin_score(data, labels),
        "calinski_harabasz_index": calinski_harabasz_score(data, labels),
        "n_components": n_components,
        "aic": gmm.aic(data),
        "bic": gmm.bic(data),
        "log_likelihood": gmm.score(data) * len(data),
    }

    logger.info(f"GMM completado: {n_components} componentes")
    logger.info(f"  Silhouette Score: {metrics['silhouette_score']:.4f}")

    return gmm, labels, metrics


def train_optics(
    data: pd.DataFrame, parameters: dict
) -> Tuple[OPTICS, pd.Series, Dict[str, Any]]:
    """Entrena modelo OPTICS.

    Args:
        data: Datos escalados.
        parameters: Parámetros de clustering.

    Returns:
        Modelo OPTICS, etiquetas y métricas.
    """
    logger.info("Entrenando modelo OPTICS...")

    optics_params = parameters.get("optics", {})
    min_samples = optics_params.get("min_samples", 5)
    max_eps = optics_params.get("max_eps", np.inf)

    optics = OPTICS(min_samples=min_samples, max_eps=max_eps)
    labels = pd.Series(optics.fit_predict(data), index=data.index)

    n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
    n_noise = list(labels).count(-1)

    metrics = {
        "n_clusters": n_clusters,
        "n_noise_points": n_noise,
        "min_samples": min_samples,
        "max_eps": max_eps if max_eps != np.inf else "inf",
    }

    # Calcular métricas solo si hay más de 1 cluster
    if n_clusters > 1:
        mask = labels != -1
        if mask.sum() > 1:
            metrics["silhouette_score"] = silhouette_score(
                data[mask], labels[mask]
            )
            metrics["davies_bouldin_index"] = davies_bouldin_score(
                data[mask], labels[mask]
            )
            metrics["calinski_harabasz_index"] = calinski_harabasz_score(
                data[mask], labels[mask]
            )
        else:
            metrics["silhouette_score"] = -1
            metrics["davies_bouldin_index"] = float("inf")
            metrics["calinski_harabasz_index"] = 0
    else:
        metrics["silhouette_score"] = -1
        metrics["davies_bouldin_index"] = float("inf")
        metrics["calinski_harabasz_index"] = 0

    logger.info(f"OPTICS completado: {n_clusters} clusters, {n_noise} puntos de ruido")

    return optics, labels, metrics


def analyze_cluster_patterns(
    data: pd.DataFrame,
    labels: pd.Series,
    original_data: pd.DataFrame,
    cluster_name: str,
    parameters: dict,
) -> Dict[str, Any]:
    """Analiza patrones profundos por cluster.

    Args:
        data: Datos escalados usados para clustering.
        labels: Etiquetas de cluster.
        original_data: Datos originales con todas las características.
        cluster_name: Nombre del algoritmo de clustering.
        parameters: Parámetros de clustering.

    Returns:
        Diccionario con análisis profundo de cada cluster.
    """
    logger.info(f"Analizando patrones de clusters para {cluster_name}...")

    # Combinar datos originales con etiquetas
    analysis_data = original_data.copy()
    analysis_data[f"{cluster_name}_cluster"] = labels

    cluster_analysis = {}

    for cluster_id in sorted(labels.unique()):
        if cluster_id == -1:  # Ruido en DBSCAN/OPTICS
            cluster_name_label = "Ruido"
        else:
            cluster_name_label = f"Cluster {cluster_id}"

        cluster_mask = labels == cluster_id
        cluster_data = analysis_data[cluster_mask]

        # Estadísticas básicas
        numeric_cols = cluster_data.select_dtypes(include=[np.number]).columns
        numeric_cols = [col for col in numeric_cols if col != f"{cluster_name}_cluster"]

        stats = {
            "n_samples": int(cluster_mask.sum()),
            "percentage": float(cluster_mask.sum() / len(labels)),
        }

        # Estadísticas por característica
        feature_stats = {}
        for col in numeric_cols[:20]:  # Limitar a 20 características principales
            feature_stats[col] = {
                "mean": float(cluster_data[col].mean()),
                "std": float(cluster_data[col].std()),
                "median": float(cluster_data[col].median()),
                "min": float(cluster_data[col].min()),
                "max": float(cluster_data[col].max()),
            }

        stats["feature_statistics"] = feature_stats

        # Perfil del cluster (características más distintivas)
        if len(numeric_cols) > 0:
            # Comparar con la media global
            global_means = analysis_data[numeric_cols].mean()
            cluster_means = cluster_data[numeric_cols].mean()

            # Características más altas que la media global
            above_avg = (cluster_means - global_means).sort_values(ascending=False).head(5)
            # Características más bajas que la media global
            below_avg = (cluster_means - global_means).sort_values(ascending=True).head(5)

            stats["distinctive_features_high"] = above_avg.to_dict()
            stats["distinctive_features_low"] = below_avg.to_dict()

        # Interpretación de negocio (si hay variable objetivo)
        target_col = parameters.get("target", "home_win")
        if target_col in cluster_data.columns:
            target_dist = cluster_data[target_col].value_counts(normalize=True)
            stats["target_distribution"] = target_dist.to_dict()
            if 1 in target_dist.index:
                stats["win_rate"] = float(target_dist[1])

        # Etiquetado semántico
        semantic_label = _generate_semantic_label(stats, feature_stats)
        stats["semantic_label"] = semantic_label

        cluster_analysis[cluster_name_label] = stats

    logger.info(f"Análisis de patrones completado para {cluster_name}")

    return cluster_analysis


def _generate_semantic_label(stats: Dict, feature_stats: Dict) -> str:
    """Genera etiqueta semántica para el cluster basado en sus características.

    Args:
        stats: Estadísticas del cluster.
        feature_stats: Estadísticas por característica.

    Returns:
        Etiqueta semántica descriptiva.
    """
    # Analizar características distintivas
    high_features = stats.get("distinctive_features_high", {})
    low_features = stats.get("distinctive_features_low", {})

    labels = []

    # Analizar características de puntos
    if "pts_home" in high_features or "pts_away" in high_features:
        labels.append("Alta Puntuación")
    elif "pts_home" in low_features or "pts_away" in low_features:
        labels.append("Baja Puntuación")

    # Analizar características defensivas
    if "reb_home" in high_features or "reb_away" in high_features:
        labels.append("Fuerte Rebote")
    if "blk_home" in high_features or "blk_away" in high_features:
        labels.append("Buena Defensa")

    # Analizar características ofensivas
    if "ast_home" in high_features or "ast_away" in high_features:
        labels.append("Buena Asistencia")
    if "fg_pct_home" in high_features or "fg_pct_away" in high_features:
        labels.append("Alta Precisión")

    if not labels:
        labels.append("Cluster Estándar")

    return " | ".join(labels)


def compare_clustering_models(
    kmeans_metrics: Dict[str, float],
    dbscan_metrics: Dict[str, Any],
    hierarchical_metrics: Dict[str, Any],
    gmm_metrics: Dict[str, float],
    optics_metrics: Dict[str, Any],
) -> pd.DataFrame:
    """Compara todos los modelos de clustering.

    Args:
        kmeans_metrics: Métricas de K-Means.
        dbscan_metrics: Métricas de DBSCAN.
        hierarchical_metrics: Métricas de clustering jerárquico.
        gmm_metrics: Métricas de GMM.
        optics_metrics: Métricas de OPTICS.

    Returns:
        DataFrame con comparación de modelos.
    """
    logger.info("Comparando modelos de clustering...")

    comparison_data = {
        "K-Means": {
            "Silhouette Score": kmeans_metrics.get("silhouette_score", -1),
            "Davies-Bouldin Index": kmeans_metrics.get("davies_bouldin_index", float("inf")),
            "Calinski-Harabasz Index": kmeans_metrics.get("calinski_harabasz_index", 0),
            "N Clusters": kmeans_metrics.get("n_clusters", 0),
        },
        "DBSCAN": {
            "Silhouette Score": dbscan_metrics.get("silhouette_score", -1),
            "Davies-Bouldin Index": dbscan_metrics.get("davies_bouldin_index", float("inf")),
            "Calinski-Harabasz Index": dbscan_metrics.get("calinski_harabasz_index", 0),
            "N Clusters": dbscan_metrics.get("n_clusters", 0),
        },
        "Hierarchical": {
            "Silhouette Score": hierarchical_metrics.get("silhouette_score", -1),
            "Davies-Bouldin Index": hierarchical_metrics.get("davies_bouldin_index", float("inf")),
            "Calinski-Harabasz Index": hierarchical_metrics.get("calinski_harabasz_index", 0),
            "N Clusters": hierarchical_metrics.get("n_clusters", 0),
        },
        "GMM": {
            "Silhouette Score": gmm_metrics.get("silhouette_score", -1),
            "Davies-Bouldin Index": gmm_metrics.get("davies_bouldin_index", float("inf")),
            "Calinski-Harabasz Index": gmm_metrics.get("calinski_harabasz_index", 0),
            "N Clusters": gmm_metrics.get("n_components", 0),
        },
        "OPTICS": {
            "Silhouette Score": optics_metrics.get("silhouette_score", -1),
            "Davies-Bouldin Index": optics_metrics.get("davies_bouldin_index", float("inf")),
            "Calinski-Harabasz Index": optics_metrics.get("calinski_harabasz_index", 0),
            "N Clusters": optics_metrics.get("n_clusters", 0),
        },
    }

    comparison_df = pd.DataFrame(comparison_data).T
    logger.info("\nComparación de modelos de clustering:")
    logger.info(f"\n{comparison_df}")

    return comparison_df


def create_clustering_visualizations(
    data: pd.DataFrame,
    kmeans_labels: pd.Series,
    dbscan_labels: pd.Series,
    hierarchical_labels: pd.Series,
    gmm_labels: pd.Series,
    optics_labels: pd.Series,
    linkage_matrix: np.ndarray,
    elbow_results: Dict[str, Any],
    parameters: dict,
) -> Dict[str, Any]:
    """Crea visualizaciones para los modelos de clustering.

    Args:
        data: Datos escalados.
        kmeans_labels: Etiquetas de K-Means.
        dbscan_labels: Etiquetas de DBSCAN.
        hierarchical_labels: Etiquetas de clustering jerárquico.
        gmm_labels: Etiquetas de GMM.
        optics_labels: Etiquetas de OPTICS.
        linkage_matrix: Matriz de linkage para dendrograma.
        elbow_results: Resultados del método del codo.
        parameters: Parámetros de clustering.

    Returns:
        Diccionario con rutas de visualizaciones guardadas.
    """
    logger.info("Creando visualizaciones de clustering...")

    # Reducir dimensionalidad para visualización 2D usando PCA
    from sklearn.decomposition import PCA

    pca = PCA(n_components=2)
    data_2d = pca.fit_transform(data)

    visualizations = {}

    # 1. Método del codo
    plt.figure(figsize=(10, 6))
    plt.plot(
        elbow_results["k_values"],
        elbow_results["inertias"],
        marker="o",
        linestyle="-",
    )
    plt.axvline(
        x=elbow_results["optimal_k"],
        color="r",
        linestyle="--",
        label=f"K óptimo: {elbow_results['optimal_k']}",
    )
    plt.xlabel("Número de Clusters (K)")
    plt.ylabel("Inercia")
    plt.title("Método del Codo - K-Means")
    plt.legend()
    plt.grid(True, alpha=0.3)
    elbow_path = "data/08_reporting/clustering_elbow_method.png"
    plt.savefig(elbow_path, dpi=300, bbox_inches="tight")
    plt.close()
    visualizations["elbow_method"] = elbow_path

    # 2. Dendrograma
    plt.figure(figsize=(15, 8))
    dendrogram(
        linkage_matrix,
        truncate_mode="level",
        p=5,
        leaf_rotation=90,
        leaf_font_size=12,
    )
    plt.title("Dendrograma - Clustering Jerárquico")
    plt.xlabel("Índice de muestra o (cluster)")
    plt.ylabel("Distancia")
    dendrogram_path = "data/08_reporting/clustering_dendrogram.png"
    plt.savefig(dendrogram_path, dpi=300, bbox_inches="tight")
    plt.close()
    visualizations["dendrogram"] = dendrogram_path

    # 3. Visualizaciones 2D de cada algoritmo
    fig, axes = plt.subplots(2, 3, figsize=(18, 12))
    axes = axes.flatten()

    algorithms = [
        ("K-Means", kmeans_labels),
        ("DBSCAN", dbscan_labels),
        ("Hierarchical", hierarchical_labels),
        ("GMM", gmm_labels),
        ("OPTICS", optics_labels),
    ]

    for idx, (name, labels) in enumerate(algorithms):
        ax = axes[idx]
        scatter = ax.scatter(
            data_2d[:, 0],
            data_2d[:, 1],
            c=labels,
            cmap="viridis",
            alpha=0.6,
            s=20,
        )
        ax.set_title(f"{name} Clustering (2D PCA)")
        ax.set_xlabel("Primera Componente Principal")
        ax.set_ylabel("Segunda Componente Principal")
        plt.colorbar(scatter, ax=ax)

    # Ocultar el último subplot
    axes[5].axis("off")

    plt.tight_layout()
    clusters_2d_path = "data/08_reporting/clustering_2d_comparison.png"
    plt.savefig(clusters_2d_path, dpi=300, bbox_inches="tight")
    plt.close()
    visualizations["clusters_2d"] = clusters_2d_path

    logger.info("Visualizaciones de clustering creadas exitosamente")

    return visualizations
