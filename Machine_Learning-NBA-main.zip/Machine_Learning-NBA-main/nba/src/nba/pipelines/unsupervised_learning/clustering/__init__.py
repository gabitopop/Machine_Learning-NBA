"""Pipeline de clustering para el proyecto NBA."""

