"""Pipeline de integración entre aprendizaje supervisado y no supervisado."""

