"""Pipeline de integración entre aprendizaje supervisado y no supervisado."""

from kedro.pipeline import Node, Pipeline

from .nodes import (
    create_clustering_features,
    evaluate_with_clustering_features,
)


def create_pipeline(**kwargs) -> Pipeline:
    """Crea el pipeline de integración para el proyecto NBA.

    Este pipeline integra resultados de clustering con modelos supervisados:
    - Usa etiquetas de cluster como features
    - Evalúa mejora en modelos supervisados
    - Compara métricas con y sin clustering features

    Returns:
        Pipeline de integración NBA.
    """
    return Pipeline(
        [
            Node(
                func=create_clustering_features,
                inputs=[
                    "model_input_table",
                    "kmeans_labels",
                    "hierarchical_labels",
                    "params:unsupervised_learning.integration",
                ],
                outputs="model_input_with_clusters",
                name="create_clustering_features_node",
                tags=["integration", "feature_engineering", "nba"],
            ),
            Node(
                func=evaluate_with_clustering_features,
                inputs=[
                    "model_input_table",
                    "model_input_with_clusters",
                    "X_train",
                    "X_val",
                    "y_train",
                    "y_val",
                    "params:unsupervised_learning.integration",
                ],
                outputs="clustering_integration_metrics",
                name="evaluate_with_clustering_features_node",
                tags=["integration", "evaluation", "nba"],
            ),
        ]
    )

