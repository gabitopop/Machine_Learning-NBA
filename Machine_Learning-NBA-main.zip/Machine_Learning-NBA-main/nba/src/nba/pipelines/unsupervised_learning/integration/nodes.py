"""Nodos para integrar clustering con modelos supervisados."""

import logging
import pandas as pd
import numpy as np
from typing import Dict, Tuple, Any
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
import json

logger = logging.getLogger(__name__)


def create_clustering_features(
    data: pd.DataFrame,
    kmeans_labels: pd.Series,
    hierarchical_labels: pd.Series,
    parameters: dict,
) -> pd.DataFrame:
    """Crea features de clustering para usar en modelos supervisados.

    Args:
        data: Datos originales.
        kmeans_labels: Etiquetas de K-Means.
        hierarchical_labels: Etiquetas de clustering jerárquico.
        parameters: Parámetros de integración.

    Returns:
        DataFrame con features de clustering agregadas.
    """
    logger.info("Creando features de clustering para modelos supervisados...")

    data_with_clusters = data.copy()

    # Agregar etiquetas de cluster como features categóricas
    data_with_clusters["kmeans_cluster"] = kmeans_labels.astype(str)
    data_with_clusters["hierarchical_cluster"] = hierarchical_labels.astype(str)

    # One-hot encoding de clusters
    kmeans_dummies = pd.get_dummies(
        data_with_clusters["kmeans_cluster"], prefix="kmeans_cluster"
    )
    hierarchical_dummies = pd.get_dummies(
        data_with_clusters["hierarchical_cluster"], prefix="hierarchical_cluster"
    )

    # Combinar
    data_with_clusters = pd.concat(
        [data_with_clusters, kmeans_dummies, hierarchical_dummies], axis=1
    )

    # Eliminar columnas originales de cluster (ya están codificadas)
    data_with_clusters = data_with_clusters.drop(
        ["kmeans_cluster", "hierarchical_cluster"], axis=1
    )

    logger.info(f"Features de clustering agregadas: {data_with_clusters.shape[1] - data.shape[1]} nuevas features")
    logger.info(f"Total de features: {data_with_clusters.shape[1]}")

    return data_with_clusters


def evaluate_with_clustering_features(
    model_input_table: pd.DataFrame,
    model_input_with_clusters: pd.DataFrame,
    X_train: pd.DataFrame,
    X_val: pd.DataFrame,
    y_train: pd.Series,
    y_val: pd.Series,
    parameters: dict,
) -> Dict[str, Any]:
    """Evalúa mejora de modelos supervisados usando features de clustering.

    Args:
        model_input_table: Datos originales sin clustering.
        model_input_with_clusters: Datos con features de clustering.
        X_train: Datos de entrenamiento originales.
        X_val: Datos de validación originales.
        y_train: Etiquetas de entrenamiento.
        y_val: Etiquetas de validación.
        parameters: Parámetros de evaluación.

    Returns:
        Diccionario con métricas de comparación.
    """
    logger.info("Evaluando mejora con features de clustering...")

    # Preparar datos con y sin clustering
    target_col = parameters.get("target", "home_win")
    
    # Sin clustering
    X_train_original = X_train.copy()
    X_val_original = X_val.copy()
    
    # Con clustering - alinear índices
    cluster_features = [col for col in model_input_with_clusters.columns 
                       if col.startswith("kmeans_cluster") or col.startswith("hierarchical_cluster")]
    X_train_with_clusters = X_train_original.copy()
    X_val_with_clusters = X_val_original.copy()
    
    # Agregar features de clustering
    for col in cluster_features:
        if col in model_input_with_clusters.columns:
            X_train_with_clusters[col] = model_input_with_clusters.loc[X_train.index, col].values
            X_val_with_clusters[col] = model_input_with_clusters.loc[X_val.index, col].values

    # Entrenar modelo sin clustering features
    model_original = RandomForestClassifier(
        n_estimators=100, random_state=42, n_jobs=-1
    )
    model_original.fit(X_train_original, y_train)
    pred_original = model_original.predict(X_val_original)
    pred_proba_original = model_original.predict_proba(X_val_original)[:, 1]

    metrics_original = {
        "accuracy": accuracy_score(y_val, pred_original),
        "precision": precision_score(y_val, pred_original),
        "recall": recall_score(y_val, pred_original),
        "f1_score": f1_score(y_val, pred_original),
        "roc_auc": roc_auc_score(y_val, pred_proba_original),
    }

    # Entrenar modelo con clustering features
    model_with_clusters = RandomForestClassifier(
        n_estimators=100, random_state=42, n_jobs=-1
    )
    model_with_clusters.fit(X_train_with_clusters, y_train)
    pred_with_clusters = model_with_clusters.predict(X_val_with_clusters)
    pred_proba_with_clusters = model_with_clusters.predict_proba(X_val_with_clusters)[:, 1]

    metrics_with_clusters = {
        "accuracy": accuracy_score(y_val, pred_with_clusters),
        "precision": precision_score(y_val, pred_with_clusters),
        "recall": recall_score(y_val, pred_with_clusters),
        "f1_score": f1_score(y_val, pred_with_clusters),
        "roc_auc": roc_auc_score(y_val, pred_proba_with_clusters),
    }

    # Calcular mejoras
    improvements = {}
    for metric in metrics_original.keys():
        improvement = metrics_with_clusters[metric] - metrics_original[metric]
        improvement_pct = (improvement / metrics_original[metric]) * 100
        improvements[metric] = {
            "absolute": float(improvement),
            "percentage": float(improvement_pct),
        }

    comparison = {
        "without_clustering": metrics_original,
        "with_clustering": metrics_with_clusters,
        "improvements": improvements,
    }

    logger.info("Comparación de modelos:")
    logger.info(f"  Sin clustering - ROC-AUC: {metrics_original['roc_auc']:.4f}")
    logger.info(f"  Con clustering - ROC-AUC: {metrics_with_clusters['roc_auc']:.4f}")
    logger.info(f"  Mejora: {improvements['roc_auc']['percentage']:.2f}%")

    return comparison

