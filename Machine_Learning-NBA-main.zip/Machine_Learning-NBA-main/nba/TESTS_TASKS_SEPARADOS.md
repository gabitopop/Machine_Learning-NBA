# Pruebas de Funcionalidad - Tasks Separados

## Resumen de Implementación

Los tasks de aprendizaje no supervisado han sido divididos en **4 tasks independientes** en el DAG de Airflow:

1. **clustering_task** - Ejecuta solo clustering (K-Means, DBSCAN, Hierarchical, GMM, OPTICS)
2. **dimensionality_reduction_task** - Ejecuta solo reducción dimensional (PCA, t-SNE, UMAP, SVD)
3. **anomaly_detection_task** - Ejecuta solo detección de anomalías (Isolation Forest, LOF, One-Class SVM, Autoencoder)
4. **association_rules_task** - Ejecuta solo reglas de asociación (Apriori, FP-Growth)

## Estructura del DAG

```
check_data_availability
    ↓
data_processing_pipeline
    ↓
data_science_pipeline
    ↓
    ├──→ clustering_task
    ├──→ dimensionality_reduction_task
    ├──→ anomaly_detection_task
    └──→ association_rules_task
    ↓ (todos deben completarse)
reporting_pipeline
    ↓
consolidate_results
    ↓
notify_completion
```

## Comandos de Ejecución

### Desde Airflow UI

1. **Ejecutar todo el DAG**: Activar y ejecutar `nba_ml_pipeline`
2. **Ejecutar solo un task**: Click derecho en el task → "Trigger Task"
   - Ejemplo: Ejecutar solo `clustering_task`

### Desde Terminal (Kedro)

```bash
# Pipeline completo de unsupervised learning
kedro run --pipeline unsupervised_learning

# Ejecutar solo clustering
kedro run --pipeline unsupervised_learning.clustering

# Ejecutar solo reducción dimensional
kedro run --pipeline unsupervised_learning.dimensionality_reduction

# Ejecutar solo detección de anomalías
kedro run --pipeline unsupervised_learning.anomaly_detection

# Ejecutar solo reglas de asociación
kedro run --pipeline unsupervised_learning.association_rules
```

### Usando Tags (Alternativa)

Si los nombres con punto no funcionan, puedes usar tags:

```bash
# Clustering
kedro run --tags clustering

# Reducción dimensional
kedro run --tags dimensionality_reduction

# Detección de anomalías
kedro run --tags anomaly_detection

# Reglas de asociación
kedro run --tags association_rules
```

## Resultados de Pruebas

### ✅ Pruebas Pasadas

1. **Estructura DAG Airflow**: ✅ PASS
   - 4 tasks independientes encontrados
   - Comandos Kedro correctos en cada task
   - Dependencias definidas correctamente

2. **Nombres de Pipelines**: ✅ PASS
   - Todos los directorios de sub-pipelines existen
   - Archivos `pipeline.py` presentes en cada uno

3. **Entradas en Catálogo**: ✅ PASS
   - Todas las entradas necesarias están definidas
   - Modelos, métricas y datos configurados

4. **Archivo de Parámetros**: ✅ PASS
   - Todas las secciones de configuración presentes

## Ventajas de Tasks Separados

### 1. Granularidad
- Puedes ejecutar solo la parte que necesitas
- Ejemplo: Solo necesitas clustering → ejecutas `clustering_task`

### 2. Manejo de Errores
- Si falla `dimensionality_reduction_task`, los demás tasks pueden completarse
- Puedes reintentar solo el task que falló

### 3. Paralelización
- Los 4 tasks pueden ejecutarse en paralelo (si no hay dependencias)
- Reduce tiempo total de ejecución

### 4. Monitoreo
- Ver progreso individual de cada categoría en Airflow UI
- Logs separados por task
- Métricas individuales por categoría

### 5. Desarrollo y Debugging
- Probar cambios en un algoritmo sin ejecutar todo
- Desarrollo más rápido y eficiente

## Comparación: Antes vs. Ahora

### Antes (1 Task)
```
unsupervised_learning_pipeline
  └── Ejecuta TODO (clustering + DR + anomalías + reglas)
  └── Si falla algo → TODO falla
  └── Tiempo: ~45 minutos
```

### Ahora (4 Tasks)
```
clustering_task                    (~12 min)
dimensionality_reduction_task      (~8 min)
anomaly_detection_task             (~10 min)
association_rules_task             (~5 min)
  └── Pueden ejecutarse en paralelo
  └── Si uno falla → los demás continúan
  └── Tiempo total: ~12 min (en paralelo) o ~35 min (secuencial)
```

## Archivos Modificados

1. **`airflow/dags/nba_ml_pipeline.py`**
   - Dividido `unsupervised_learning_pipeline` en 4 tasks separados
   - Dependencias actualizadas

2. **`src/nba/pipeline_registry.py`**
   - Registrados sub-pipelines individuales:
     - `unsupervised_learning.clustering`
     - `unsupervised_learning.dimensionality_reduction`
     - `unsupervised_learning.anomaly_detection`
     - `unsupervised_learning.association_rules`

## Próximos Pasos

1. **Probar en Airflow**: Ejecutar el DAG completo y verificar que cada task funciona
2. **Probar individualmente**: Ejecutar cada task por separado desde Airflow UI
3. **Verificar outputs**: Confirmar que cada task genera sus outputs esperados
4. **Optimizar dependencias**: Si es posible, ejecutar tasks en paralelo

## Notas Técnicas

- Los nombres de pipelines con punto (`unsupervised_learning.clustering`) están registrados explícitamente en `pipeline_registry.py`
- Si estos nombres no funcionan, se puede usar tags como alternativa
- Los tasks en Airflow ejecutan comandos Kedro que son independientes entre sí
- Cada task tiene su propio contexto de ejecución y puede fallar sin afectar a los demás

