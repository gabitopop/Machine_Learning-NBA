# Script completo de pruebas de Docker para el proyecto NBA (PowerShell)
# Este script ejecuta todas las pruebas necesarias para verificar Docker

$ErrorActionPreference = "Stop"

Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "PRUEBAS COMPLETAS DE DOCKER - PROYECTO NBA" -ForegroundColor Cyan
Write-Host "======================================================================"
Write-Host ""

# Verificar Docker
Write-Host "1. Verificando Docker..." -ForegroundColor Yellow
try {
    $dockerVersion = docker --version 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✓ Docker instalado: $dockerVersion" -ForegroundColor Green
    } else {
        Write-Host "✗ Docker no está instalado" -ForegroundColor Red
        exit 1
    }
} catch {
    Write-Host "✗ Docker no está instalado" -ForegroundColor Red
    exit 1
}

# Verificar Docker Compose
Write-Host ""
Write-Host "2. Verificando Docker Compose..." -ForegroundColor Yellow
$composeCmd = $null
try {
    $composeVersion = docker compose version 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✓ Docker Compose disponible: $composeVersion" -ForegroundColor Green
        $composeCmd = "docker compose"
    }
} catch {
    try {
        $composeVersion = docker-compose --version 2>&1
        if ($LASTEXITCODE -eq 0) {
            Write-Host "✓ docker-compose disponible: $composeVersion" -ForegroundColor Green
            $composeCmd = "docker-compose"
        }
    } catch {
        Write-Host "✗ Docker Compose no está disponible" -ForegroundColor Red
        exit 1
    }
}

# Verificar que Docker esté corriendo
Write-Host ""
Write-Host "3. Verificando que Docker esté corriendo..." -ForegroundColor Yellow
try {
    docker info 2>&1 | Out-Null
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✓ Docker daemon está corriendo" -ForegroundColor Green
    } else {
        Write-Host "✗ Docker daemon no está corriendo. Inicia Docker Desktop." -ForegroundColor Red
        exit 1
    }
} catch {
    Write-Host "✗ Docker daemon no está corriendo. Inicia Docker Desktop." -ForegroundColor Red
    exit 1
}

# Validar docker-compose.yml
Write-Host ""
Write-Host "4. Validando docker-compose.yml..." -ForegroundColor Yellow
try {
    if ($composeCmd -eq "docker compose") {
        docker compose config 2>&1 | Out-Null
    } else {
        docker-compose config 2>&1 | Out-Null
    }
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✓ docker-compose.yml es válido" -ForegroundColor Green
    } else {
        Write-Host "✗ docker-compose.yml tiene errores" -ForegroundColor Red
        if ($composeCmd -eq "docker compose") {
            docker compose config
        } else {
            docker-compose config
        }
        exit 1
    }
} catch {
    Write-Host "✗ Error al validar docker-compose.yml" -ForegroundColor Red
    exit 1
}

# Limpiar contenedores anteriores
Write-Host ""
Write-Host "5. Limpiando contenedores anteriores..." -ForegroundColor Yellow
try {
    if ($composeCmd -eq "docker compose") {
        docker compose down -v 2>&1 | Out-Null
    } else {
        docker-compose down -v 2>&1 | Out-Null
    }
    Write-Host "✓ Contenedores anteriores limpiados" -ForegroundColor Green
} catch {
    Write-Host "⚠ No se pudieron limpiar contenedores anteriores (puede ser normal)" -ForegroundColor Yellow
}

# Construir imágenes
Write-Host ""
Write-Host "6. Construyendo imágenes Docker..." -ForegroundColor Yellow
Write-Host "   Esto puede tardar varios minutos..." -ForegroundColor Gray
try {
    if ($composeCmd -eq "docker compose") {
        docker compose build
    } else {
        docker-compose build
    }
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✓ Imágenes construidas exitosamente" -ForegroundColor Green
    } else {
        Write-Host "✗ Error al construir imágenes" -ForegroundColor Red
        exit 1
    }
} catch {
    Write-Host "✗ Error al construir imágenes" -ForegroundColor Red
    exit 1
}

# Levantar servicios
Write-Host ""
Write-Host "7. Levantando servicios..." -ForegroundColor Yellow
try {
    if ($composeCmd -eq "docker compose") {
        docker compose up -d
    } else {
        docker-compose up -d
    }
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✓ Servicios levantados" -ForegroundColor Green
    } else {
        Write-Host "✗ Error al levantar servicios" -ForegroundColor Red
        exit 1
    }
} catch {
    Write-Host "✗ Error al levantar servicios" -ForegroundColor Red
    exit 1
}

# Esperar a que los servicios inicien
Write-Host ""
Write-Host "8. Esperando a que los servicios inicien (30 segundos)..." -ForegroundColor Yellow
Start-Sleep -Seconds 30

# Verificar estado de servicios
Write-Host ""
Write-Host "9. Verificando estado de servicios..." -ForegroundColor Yellow
if ($composeCmd -eq "docker compose") {
    docker compose ps
} else {
    docker-compose ps
}

# Verificar que los servicios estén corriendo
Write-Host ""
Write-Host "10. Verificando salud de servicios..." -ForegroundColor Yellow
$services = @("nba-ml", "nba-jupyter", "nba-airflow")
$allRunning = $true

foreach ($service in $services) {
    $status = if ($composeCmd -eq "docker compose") {
        docker compose ps | Select-String $service
    } else {
        docker-compose ps | Select-String $service
    }
    
    if ($status -match "Up") {
        Write-Host "✓ Servicio $service está corriendo" -ForegroundColor Green
    } else {
        Write-Host "✗ Servicio $service NO está corriendo" -ForegroundColor Red
        $allRunning = $false
    }
}

# Ver logs de errores
if (-not $allRunning) {
    Write-Host ""
    Write-Host "⚠ Algunos servicios no están corriendo. Revisando logs..." -ForegroundColor Yellow
    if ($composeCmd -eq "docker compose") {
        docker compose logs --tail=50
    } else {
        docker-compose logs --tail=50
    }
}

# Probar ejecución de pipeline
Write-Host ""
Write-Host "11. Probando ejecución de pipeline..." -ForegroundColor Yellow
try {
    if ($composeCmd -eq "docker compose") {
        docker compose run --rm nba-ml kedro pipeline list 2>&1 | Out-Null
    } else {
        docker-compose run --rm nba-ml kedro pipeline list 2>&1 | Out-Null
    }
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✓ Kedro funciona en el contenedor" -ForegroundColor Green
        Write-Host "   Pipelines disponibles:" -ForegroundColor Gray
        if ($composeCmd -eq "docker compose") {
            docker compose run --rm nba-ml kedro pipeline list
        } else {
            docker-compose run --rm nba-ml kedro pipeline list
        }
    } else {
        Write-Host "✗ Error al ejecutar Kedro en el contenedor" -ForegroundColor Red
        if ($composeCmd -eq "docker compose") {
            docker compose logs nba-ml --tail=20
        } else {
            docker-compose logs nba-ml --tail=20
        }
    }
} catch {
    Write-Host "✗ Error al ejecutar Kedro en el contenedor" -ForegroundColor Red
}

# Resumen final
Write-Host ""
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "RESUMEN DE PRUEBAS" -ForegroundColor Cyan
Write-Host "======================================================================"
Write-Host ""
Write-Host "Servicios disponibles:" -ForegroundColor Yellow
Write-Host "  - Airflow UI: http://localhost:8080 (admin/admin)" -ForegroundColor White
Write-Host "  - Jupyter: http://localhost:8888" -ForegroundColor White
Write-Host ""
Write-Host "Comandos útiles:" -ForegroundColor Yellow
Write-Host "  Ver logs: $composeCmd logs -f" -ForegroundColor White
Write-Host "  Detener: $composeCmd down" -ForegroundColor White
Write-Host "  Estado: $composeCmd ps" -ForegroundColor White
Write-Host ""
Write-Host "Para ejecutar un pipeline:" -ForegroundColor Yellow
Write-Host "  $composeCmd run --rm nba-ml kedro run --pipeline <nombre>" -ForegroundColor White
Write-Host ""
Write-Host "======================================================================" -ForegroundColor Cyan

if ($allRunning) {
    Write-Host "✓ TODAS LAS PRUEBAS PASARON" -ForegroundColor Green
    exit 0
} else {
    Write-Host "✗ ALGUNAS PRUEBAS FALLARON" -ForegroundColor Red
    exit 1
}

