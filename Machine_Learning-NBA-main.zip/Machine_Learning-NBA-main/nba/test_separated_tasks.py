"""
Script de prueba para validar que los tasks separados de unsupervised learning
pueden ejecutarse individualmente.

Este script prueba:
1. Que los pipelines individuales están registrados
2. Que se pueden ejecutar por separado
3. Que generan los outputs esperados
"""

import sys
import os
from pathlib import Path

# Agregar el directorio src al path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root / "src"))

def test_pipeline_registration():
    """Prueba que los pipelines individuales están registrados."""
    print("=" * 60)
    print("TEST 1: Verificación de Registro de Pipelines")
    print("=" * 60)
    
    try:
        from kedro.framework.project import configure_project
        from kedro.framework.session import KedroSession
        
        configure_project("nba")
        session = KedroSession.create("nba")
        context = session.load_context()
        
        # Obtener pipelines registrados
        from nba.pipeline_registry import register_pipelines
        pipelines = register_pipelines()
        
        # Pipelines que deberían existir
        required_pipelines = [
            "unsupervised_learning",
            "unsupervised_learning.clustering",
            "unsupervised_learning.dimensionality_reduction",
            "unsupervised_learning.anomaly_detection",
            "unsupervised_learning.association_rules",
        ]
        
        print("\nPipelines disponibles:")
        available_pipelines = list(pipelines.keys())
        for pipeline_name in sorted(available_pipelines):
            if "unsupervised" in pipeline_name.lower():
                print(f"  ✓ {pipeline_name}")
        
        print("\nPipelines requeridos:")
        missing_pipelines = []
        for pipeline_name in required_pipelines:
            if pipeline_name in pipelines:
                print(f"  OK {pipeline_name} - REGISTRADO")
            else:
                print(f"  X {pipeline_name} - NO ENCONTRADO")
                missing_pipelines.append(pipeline_name)
        
        if missing_pipelines:
            print(f"\n⚠️  ADVERTENCIA: {len(missing_pipelines)} pipelines no encontrados")
            print("   Los sub-pipelines pueden ejecutarse usando tags o nombres completos")
            return False
        else:
            print("\nOK Todos los pipelines requeridos estan registrados")
            return True
            
    except Exception as e:
        print(f"\nERROR: Error al verificar pipelines: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_pipeline_structure():
    """Prueba la estructura de los pipelines individuales."""
    print("\n" + "=" * 60)
    print("TEST 2: Verificación de Estructura de Pipelines")
    print("=" * 60)
    
    try:
        from kedro.framework.project import configure_project
        from kedro.framework.session import KedroSession
        
        configure_project("nba")
        session = KedroSession.create("nba")
        context = session.load_context()
        
        # Obtener el pipeline completo de unsupervised learning
        from nba.pipeline_registry import register_pipelines
        pipelines = register_pipelines()
        unsupervised_pipeline = pipelines.get("unsupervised_learning")
        
        if unsupervised_pipeline is None:
            print("❌ Pipeline 'unsupervised_learning' no encontrado")
            return False
        
        # Obtener nodos del pipeline
        nodes = list(unsupervised_pipeline.nodes)
        
        print(f"\nPipeline 'unsupervised_learning' contiene {len(nodes)} nodos")
        
        # Agrupar por tags para identificar sub-pipelines
        clustering_nodes = [n for n in nodes if "clustering" in str(n.tags)]
        dr_nodes = [n for n in nodes if "dimensionality_reduction" in str(n.tags)]
        anomaly_nodes = [n for n in nodes if "anomaly_detection" in str(n.tags)]
        association_nodes = [n for n in nodes if "association" in str(n.tags)]
        
        print(f"\nDistribución de nodos:")
        print(f"  - Clustering: {len(clustering_nodes)} nodos")
        print(f"  - Dimensionality Reduction: {len(dr_nodes)} nodos")
        print(f"  - Anomaly Detection: {len(anomaly_nodes)} nodos")
        print(f"  - Association Rules: {len(association_nodes)} nodos")
        
        # Verificar que hay nodos en cada categoría
        if len(clustering_nodes) > 0 and len(dr_nodes) > 0:
            print("\nOK Estructura de pipelines validada correctamente")
            return True
        else:
            print("\n⚠️  Algunos sub-pipelines pueden estar vacíos")
            return False
            
    except Exception as e:
        print(f"\n❌ Error al verificar estructura: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_kedro_commands():
    """Prueba que los comandos de Kedro funcionan correctamente."""
    print("\n" + "=" * 60)
    print("TEST 3: Verificación de Comandos Kedro")
    print("=" * 60)
    
    import subprocess
    
    # Comandos a probar
    commands = [
        ("kedro pipeline list", "Listar pipelines disponibles"),
        ("kedro pipeline describe unsupervised_learning", "Describir pipeline completo"),
    ]
    
    results = []
    
    for cmd, description in commands:
        print(f"\n{description}:")
        print(f"  Comando: {cmd}")
        try:
            # Ejecutar comando (solo verificar que existe, no ejecutar completo)
            result = subprocess.run(
                cmd.split(),
                cwd=project_root,
                capture_output=True,
                text=True,
                timeout=10
            )
            
            if result.returncode == 0:
                print(f"  OK Comando ejecutado exitosamente")
                # Mostrar primeras líneas de salida
                output_lines = result.stdout.split('\n')[:5]
                for line in output_lines:
                    if line.strip():
                        print(f"     {line}")
                results.append(True)
            else:
                print(f"  ⚠️  Comando retornó código {result.returncode}")
                if result.stderr:
                    print(f"     Error: {result.stderr[:200]}")
                results.append(False)
                
        except FileNotFoundError:
            print(f"  ⚠️  Kedro no encontrado en PATH (esto es normal si no está instalado)")
            results.append(False)
        except subprocess.TimeoutExpired:
            print(f"  ⚠️  Comando tardó demasiado (timeout)")
            results.append(False)
        except Exception as e:
            print(f"  ❌ Error: {e}")
            results.append(False)
    
    if any(results):
        print("\nOK Al menos un comando funciono correctamente")
        return True
    else:
        print("\n⚠️  Los comandos no se pudieron ejecutar (puede ser normal si Kedro no está instalado)")
        return True  # No fallar el test si Kedro no está instalado


def test_airflow_dag_structure():
    """Prueba que el DAG de Airflow tiene la estructura correcta."""
    print("\n" + "=" * 60)
    print("TEST 4: Verificación de Estructura del DAG de Airflow")
    print("=" * 60)
    
    dag_file = project_root / "airflow" / "dags" / "nba_ml_pipeline.py"
    
    if not dag_file.exists():
        print(f"❌ Archivo DAG no encontrado: {dag_file}")
        return False
    
    # Leer el archivo DAG
    with open(dag_file, 'r', encoding='utf-8') as f:
        dag_content = f.read()
    
    # Verificar que existen los tasks separados
    required_tasks = [
        "clustering_task",
        "dimensionality_reduction_task",
        "anomaly_detection_task",
        "association_rules_task",
    ]
    
    print("\nTasks requeridos en el DAG:")
    missing_tasks = []
    for task_name in required_tasks:
        if task_name in dag_content:
            # Verificar que tiene el comando correcto
            if f"task_id='{task_name}'" in dag_content:
                print(f"  OK {task_name} - ENCONTRADO")
            else:
                print(f"  ⚠️  {task_name} - Encontrado pero sin task_id correcto")
                missing_tasks.append(task_name)
        else:
            print(f"  X {task_name} - NO ENCONTRADO")
            missing_tasks.append(task_name)
    
    # Verificar comandos de Kedro
    print("\nComandos Kedro en tasks:")
    kedro_commands = [
        ("unsupervised_learning.clustering", "clustering_task"),
        ("unsupervised_learning.dimensionality_reduction", "dimensionality_reduction_task"),
        ("unsupervised_learning.anomaly_detection", "anomaly_detection_task"),
        ("unsupervised_learning.association_rules", "association_rules_task"),
    ]
    
    for pipeline_name, task_name in kedro_commands:
        if f"--pipeline {pipeline_name}" in dag_content:
            print(f"  OK {task_name} ejecuta: kedro run --pipeline {pipeline_name}")
        else:
            print(f"  X {task_name} no tiene comando para {pipeline_name}")
            missing_tasks.append(task_name)
    
    # Verificar dependencias
    print("\nDependencias entre tasks:")
    if "clustering_task" in dag_content and "dimensionality_reduction_task" in dag_content:
        if ">>" in dag_content or "set_downstream" in dag_content:
            print("  OK Dependencias definidas")
        else:
            print("  ⚠️  Dependencias no encontradas explícitamente")
    
    if missing_tasks:
        print(f"\n⚠️  {len(missing_tasks)} tasks o comandos faltantes")
        return False
    else:
        print("\nOK Estructura del DAG validada correctamente")
        return True


def test_catalog_entries():
    """Prueba que el catálogo tiene las entradas necesarias."""
    print("\n" + "=" * 60)
    print("TEST 5: Verificación de Entradas en Catálogo")
    print("=" * 60)
    
    catalog_file = project_root / "conf" / "base" / "catalog.yml"
    
    if not catalog_file.exists():
        print(f"❌ Archivo de catálogo no encontrado: {catalog_file}")
        return False
    
    with open(catalog_file, 'r', encoding='utf-8') as f:
        catalog_content = f.read()
    
    # Entradas clave que deberían existir
    required_entries = [
        "clustering_data",
        "kmeans_model",
        "pca_model",
        "pca_metrics",
        "isolation_forest_model",
        "apriori_rules",
    ]
    
    print("\nEntradas requeridas en catálogo:")
    missing_entries = []
    for entry in required_entries:
        if entry in catalog_content:
            print(f"  OK {entry}")
        else:
            print(f"  X {entry} - NO ENCONTRADO")
            missing_entries.append(entry)
    
    if missing_entries:
        print(f"\n⚠️  {len(missing_entries)} entradas faltantes")
        return False
    else:
        print("\nOK Catalogo validado correctamente")
        return True


def main():
    """Ejecuta todos los tests."""
    print("\n" + "=" * 60)
    print("PRUEBAS DE FUNCIONALIDAD - TASKS SEPARADOS")
    print("=" * 60)
    print("\nEste script valida que los tasks separados de unsupervised learning")
    print("están correctamente configurados y pueden ejecutarse individualmente.\n")
    
    tests = [
        ("Registro de Pipelines", test_pipeline_registration),
        ("Estructura de Pipelines", test_pipeline_structure),
        ("Comandos Kedro", test_kedro_commands),
        ("Estructura DAG Airflow", test_airflow_dag_structure),
        ("Entradas en Catálogo", test_catalog_entries),
    ]
    
    results = []
    
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"\nERROR en test '{test_name}': {e}")
            results.append((test_name, False))
    
    # Resumen final
    print("\n" + "=" * 60)
    print("RESUMEN DE PRUEBAS")
    print("=" * 60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "PASS" if result else "FAIL"
        print(f"{status} - {test_name}")
    
    print(f"\n{'=' * 60}")
    print(f"Total: {passed}/{total} pruebas pasadas")
    print(f"{'=' * 60}\n")
    
    if passed == total:
        print("TODAS LAS PRUEBAS PASARON")
        print("\nLos tasks separados están correctamente configurados.")
        print("Puedes ejecutar cada pipeline individualmente usando:")
        print("  - kedro run --pipeline unsupervised_learning.clustering")
        print("  - kedro run --pipeline unsupervised_learning.dimensionality_reduction")
        print("  - kedro run --pipeline unsupervised_learning.anomaly_detection")
        print("  - kedro run --pipeline unsupervised_learning.association_rules")
        return 0
    else:
        print("ALGUNAS PRUEBAS FALLARON")
        print("Revisa los resultados arriba para más detalles.")
        return 1


if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)

