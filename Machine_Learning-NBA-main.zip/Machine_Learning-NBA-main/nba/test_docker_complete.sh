#!/bin/bash
# Script completo de pruebas de Docker para el proyecto NBA
# Este script ejecuta todas las pruebas necesarias para verificar Docker

set -e  # Salir si hay errores

echo "======================================================================"
echo "PRUEBAS COMPLETAS DE DOCKER - PROYECTO NBA"
echo "======================================================================"
echo ""

# Colores para output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Función para imprimir éxito
success() {
    echo -e "${GREEN}✓${NC} $1"
}

# Función para imprimir error
error() {
    echo -e "${RED}✗${NC} $1"
}

# Función para imprimir advertencia
warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

# Verificar Docker
echo "1. Verificando Docker..."
if command -v docker &> /dev/null; then
    DOCKER_VERSION=$(docker --version)
    success "Docker instalado: $DOCKER_VERSION"
else
    error "Docker no está instalado"
    exit 1
fi

# Verificar Docker Compose
echo ""
echo "2. Verificando Docker Compose..."
if docker compose version &> /dev/null; then
    COMPOSE_VERSION=$(docker compose version)
    success "Docker Compose disponible: $COMPOSE_VERSION"
    COMPOSE_CMD="docker compose"
elif command -v docker-compose &> /dev/null; then
    COMPOSE_VERSION=$(docker-compose --version)
    success "docker-compose disponible: $COMPOSE_VERSION"
    COMPOSE_CMD="docker-compose"
else
    error "Docker Compose no está disponible"
    exit 1
fi

# Verificar que Docker esté corriendo
echo ""
echo "3. Verificando que Docker esté corriendo..."
if docker info &> /dev/null; then
    success "Docker daemon está corriendo"
else
    error "Docker daemon no está corriendo. Inicia Docker Desktop."
    exit 1
fi

# Validar docker-compose.yml
echo ""
echo "4. Validando docker-compose.yml..."
if $COMPOSE_CMD config &> /dev/null; then
    success "docker-compose.yml es válido"
else
    error "docker-compose.yml tiene errores"
    $COMPOSE_CMD config
    exit 1
fi

# Limpiar contenedores anteriores
echo ""
echo "5. Limpiando contenedores anteriores..."
$COMPOSE_CMD down -v 2>/dev/null || true
success "Contenedores anteriores limpiados"

# Construir imágenes
echo ""
echo "6. Construyendo imágenes Docker..."
echo "   Esto puede tardar varios minutos..."
if $COMPOSE_CMD build --progress=plain; then
    success "Imágenes construidas exitosamente"
else
    error "Error al construir imágenes"
    exit 1
fi

# Levantar servicios
echo ""
echo "7. Levantando servicios..."
if $COMPOSE_CMD up -d; then
    success "Servicios levantados"
else
    error "Error al levantar servicios"
    exit 1
fi

# Esperar a que los servicios inicien
echo ""
echo "8. Esperando a que los servicios inicien (30 segundos)..."
sleep 30

# Verificar estado de servicios
echo ""
echo "9. Verificando estado de servicios..."
$COMPOSE_CMD ps

# Verificar que los servicios estén corriendo
echo ""
echo "10. Verificando salud de servicios..."
SERVICES=("nba-ml" "nba-jupyter" "nba-airflow")
ALL_RUNNING=true

for service in "${SERVICES[@]}"; do
    if $COMPOSE_CMD ps | grep -q "$service.*Up"; then
        success "Servicio $service está corriendo"
    else
        error "Servicio $service NO está corriendo"
        ALL_RUNNING=false
    fi
done

# Ver logs de errores
if [ "$ALL_RUNNING" = false ]; then
    echo ""
    warning "Algunos servicios no están corriendo. Revisando logs..."
    $COMPOSE_CMD logs --tail=50
fi

# Probar ejecución de pipeline
echo ""
echo "11. Probando ejecución de pipeline..."
if $COMPOSE_CMD run --rm nba-ml kedro pipeline list &> /dev/null; then
    success "Kedro funciona en el contenedor"
    echo "   Pipelines disponibles:"
    $COMPOSE_CMD run --rm nba-ml kedro pipeline list | grep -E "^-" || true
else
    error "Error al ejecutar Kedro en el contenedor"
    $COMPOSE_CMD logs nba-ml --tail=20
fi

# Verificar puertos
echo ""
echo "12. Verificando puertos..."
PORTS=("8080:Airflow" "8888:Jupyter")
for port_info in "${PORTS[@]}"; do
    IFS=':' read -r port name <<< "$port_info"
    if netstat -an 2>/dev/null | grep -q ":$port " || ss -an 2>/dev/null | grep -q ":$port "; then
        success "Puerto $port ($name) está abierto"
    else
        warning "Puerto $port ($name) no parece estar abierto"
    fi
done

# Resumen final
echo ""
echo "======================================================================"
echo "RESUMEN DE PRUEBAS"
echo "======================================================================"
echo ""
echo "Servicios disponibles:"
echo "  - Airflow UI: http://localhost:8080 (admin/admin)"
echo "  - Jupyter: http://localhost:8888"
echo ""
echo "Comandos útiles:"
echo "  Ver logs: $COMPOSE_CMD logs -f"
echo "  Detener: $COMPOSE_CMD down"
echo "  Estado: $COMPOSE_CMD ps"
echo ""
echo "Para ejecutar un pipeline:"
echo "  $COMPOSE_CMD run --rm nba-ml kedro run --pipeline <nombre>"
echo ""
echo "======================================================================"

if [ "$ALL_RUNNING" = true ]; then
    success "TODAS LAS PRUEBAS PASARON"
    exit 0
else
    error "ALGUNAS PRUEBAS FALLARON"
    exit 1
fi

